package com.itheima.proxy.staticis;

public class Baobao implements Star {
    @Override
    public void sing(String song) {
        System.out.println("宝宝唱歌：" + song);
    }

    @Override
    public String dance(String name) {
        return "宝宝跳舞：" + name;
    }
}
