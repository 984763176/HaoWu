package com.itheima.proxy.staticis;

public class ProxyTest {
    public static void main(String[] args) {
        //要有一个被代理对象存在
        Baobao bao = new Baobao();
        //创建代理类对象
        ProxyObj proxy = new ProxyObj(bao);
        //通过代理类的方法，最终执行被代理对象的方法
        proxy.sing("绿光");
        String dance = proxy.dance("C哩C哩");
        System.out.println(dance);
    }
}
