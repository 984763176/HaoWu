package com.itheima.proxy.staticis;

public interface Star {

    public void sing(String song);

    public String dance(String name);
}
