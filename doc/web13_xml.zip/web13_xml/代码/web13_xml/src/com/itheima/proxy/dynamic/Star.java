package com.itheima.proxy.dynamic;

public interface Star {

    public void sing(String song);

    public String dance(String name);
}
