package com.itheima.xml;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.junit.Test;

import java.util.List;

public class Demo01XmlParser {

    /**
     * 使用dom4j的基础步骤：
     * 读取XML文档，得到Document对象。
     * 获取根标签
     */
    @Test
    public void demo1() throws DocumentException {
        //1. 创建一个解析器对象
        SAXReader reader = new SAXReader();
        //2. 读取XML文档，得到一个Document对象
        String path = Demo01XmlParser.class.getClassLoader().getResource("com\\itheima\\xml\\books.xml").getPath();
        Document document = reader.read(path);
        //3. 获取根标签对象
        Element rootElement = document.getRootElement();

        System.out.println(rootElement);
    }

    /**
     * 获取子标签
     */
    @Test
    public void demo2() throws DocumentException {
        //1. 创建一个解析器对象
        SAXReader reader = new SAXReader();
        //2. 读取XML文档，得到一个Document对象
        String path = Demo01XmlParser.class.getClassLoader().getResource("com\\itheima\\xml\\books.xml").getPath();
        Document document = reader.read(path);
        //3. 获取根标签对象
        Element rootElement = document.getRootElement();

        //4. 获取根标签的第一个book子标签对象
        Element bookElement = rootElement.element("book");
        //System.out.println(bookElement);
        //4.1 获取这个book节点里的name子标签
        Element name = bookElement.element("name");

        //4.2 获取name标签里的文本
        String text = name.getText();
        text = name.getTextTrim();
        System.out.println(text);

        //5. 获取根标签的所有book子标签对象
        List<Element> bookList = rootElement.elements("book");
        //System.out.println(bookList);

        //6. 获取根标签的所有子标签对象
        List<Element> elements = rootElement.elements();
        //System.out.println(elements);
    }

    @Test
    public void demo3() throws DocumentException {
        //1. 创建一个解析器对象
        SAXReader reader = new SAXReader();
        //2. 读取XML文档，得到一个Document对象
        String path = Demo01XmlParser.class.getClassLoader().getResource("com\\itheima\\xml\\books.xml").getPath();
        Document document = reader.read(path);
        //3. 获取根标签对象
        Element rootElement = document.getRootElement();
        //4. 获取第二个book子标签
        List<Element> bookList = rootElement.elements("book");
        Element bookElement = bookList.get(1);
        //5. 获取子标签desc
        Element desc = bookElement.element("desc");
        //6. 获取desc的内容
        String text = desc.getText();

        text = desc.getTextTrim();
        System.out.println(text);

    }

    @Test
    public void demo4() throws DocumentException {
        //1. 创建一个解析器对象
        SAXReader reader = new SAXReader();
        //2. 读取XML文档，得到一个Document对象
        String path = Demo01XmlParser.class.getClassLoader().getResource("com\\itheima\\xml\\books.xml").getPath();
        Document document = reader.read(path);
        //3. 获取根标签对象
        Element rootElement = document.getRootElement();

        //4. 获取根标签的第一个book子标签
        Element book = rootElement.element("book");
        //5. 获取标签的publish属性值
        /*Attribute publishAttr = book.attribute("publish");
        String value = publishAttr.getValue();
        System.out.println(value);*/

        String value = book.attributeValue("publish");
        System.out.println(value);

    }
}
