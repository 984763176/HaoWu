package com.itheima.xml.yueshu;

import java.util.Date;

public class Demo01NameSpace {
    public static void main(String[] args) {
        java.util.Date date = new Date();

        java.sql.Date sqlDate = null;
    }
}
