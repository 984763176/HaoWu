package com.itheima.xml;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.junit.Test;

import java.util.List;

public class Demo02XmlXpathParser {

    /**
     * 使用xpath解析XML
     */
    @Test
    public void demo1() throws DocumentException {
        //1. 创建解析器对象
        SAXReader reader = new SAXReader();
        //2. 读取XML，得到Document对象
        String path = Demo02XmlXpathParser.class.getClassLoader().getResource("\\com\\itheima\\xml\\books.xml").getPath();
        Document document = reader.read(path);
        //3. 使用XPath表达式查找节点

        //3.1 查找所有book标签对象  //book
        List<Node> nodes = document.selectNodes("//book");
        /*for (Node node : nodes) {
            Element element = (Element) node;
            System.out.println(element);
        }*/

        //3.1 查找所有book标签对象的子标签name  //book/name
        List<Node> nameList = document.selectNodes("//book/name");
        for (Node node : nameList) {
            Element element = (Element) node;
            System.out.println(element.getText());
        }

    }

    @Test
    public void demo2() throws DocumentException {
        //1. 创建解析器对象
        SAXReader reader = new SAXReader();
        //2. 读取XML，得到Document对象
        String path = Demo02XmlXpathParser.class.getClassLoader().getResource("\\com\\itheima\\xml\\books.xml").getPath();
        Document document = reader.read(path);
        //3. 获取id属性值为book1 的标签  //book[@id='book1']
        Element element = (Element) document.selectSingleNode("//book[@id='book1']");
        //System.out.println(element);

        Element nameElement = (Element) document.selectSingleNode("//book[@id='book1']/name");
        System.out.println(nameElement.getText());
    }
}
