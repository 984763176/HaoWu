package com.itheima.proxy.staticis;

public class ProxyObj implements Star {

    private Baobao bao;

    public ProxyObj(Baobao bao) {
        this.bao = bao;
    }

    @Override
    public void sing(String song) {
        song = "老子今天不上班";
        bao.sing(song);
    }

    @Override
    public String dance(String name) {
        return bao.dance(name);
    }
}
