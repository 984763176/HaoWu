package com.itheima.proxy.dynamic;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class ProxyTest {
    public static void main(String[] args) {
        //要有一个被代理对象存在
        Baobao bao = new Baobao();
        //调用Proxy的API，动态生成代理类，并创建代理类对象给我们
        /**
         * 参数：
         *  类加载器：
         *  接口数组：Class[]
         *      String[] strs = new String[]{"a","b","c"};
         *      Class[] clsarr = new Class[]{类.class, 类.class}
         */
        Star proxy = (Star) Proxy.newProxyInstance(bao.getClass().getClassLoader(), bao.getClass().getInterfaces(), new InvocationHandler() {
            /**
             * 指定代理对象的行为
             * @param proxy 代理对象
             * @param method 要执行的方法Method对象
             * @param args 要执行的方法需要的参数
             * @return
             * @throws Throwable
             */
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                //调用目标对象的方法method
                Object result = method.invoke(bao, args);

                //返回执行的结果
                return result;
            }
        });

        //调用代理对象的方法
        proxy.sing("绿光");
        String dance = proxy.dance("海草舞");
        System.out.println(dance);
    }

    /**
     * 生成代理对象
     * @param obj 目标对象
     * @return 目标对象的代理对象
     */
    public static Object getProxy(Object obj){
        return  Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                Object result = method.invoke(obj, args);
                return result;
            }
        });
    }
}
