package com.itheima.web;

import com.itheima.domain.User;
import com.itheima.util.JdbcUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/login", name="LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //解决乱码
        request.setCharacterEncoding("utf-8");
        //接收参数
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        /***********验证码校验**********/
        String checkcode = request.getParameter("checkcode");
        //从session中获取验证码真实值
        String checkcode_server = (String) request.getSession().getAttribute("CHECKCODE_SERVER");
        //清除掉session里的验证码真实值，保证 一个验证码只使用一次
        request.getSession().removeAttribute("CHECKCODE_SERVER");

        //比较两个值是否一致
        if(!checkcode_server.equalsIgnoreCase(checkcode)){
            //把错误信息放在request域里，请求转发到login.jsp
            request.setAttribute("loginInfo", "验证码输入错误");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }


        //处理业务请求：执行SQL语句
        JdbcTemplate jdbcTemplate = new JdbcTemplate(JdbcUtils.getDataSource());
        User user = null;
        try {
            user = jdbcTemplate.queryForObject("select * from user where username = ? and password = ?", new BeanPropertyRowMapper<>(User.class), username, password);
        } catch (DataAccessException e) {
            System.out.println("根据用户名["+username+"]和密码["+password+"]查询没有结果");
        }

        //页面跳转
        if (user == null) {//登录失败
            //跳转到登录页，并且在登录页上显示错误信息
            request.setAttribute("loginInfo", "用户名或密码错误");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }else{//登录成功
            //重定向跳转到首页
            response.sendRedirect(request.getContextPath()+"/index.jsp");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}