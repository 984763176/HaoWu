package com.itheima.session;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(urlPatterns="/getSession", name="Demo01GetSessionServlet")
public class Demo01GetSessionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取到一个session对象
        /**
         * getSession方法底层的原理：
         *  1. 先从request里获取名称为JSESSIONID的Cookie对象
         *  2. 如果获取不到，说明浏览器没有访问过，服务器软件会创建一个session对象
         *  3. 如果获取到了，说明浏览器访问过
         *      服务器根据JSESSIONID的值，查找对应的session对象
         *  返回session对象
         *
         * getSession方法的两个作用：
         *  1. 可以创建session对象
         *  2. 可以自动根据客户端的JSESSIONID，查找session对象
         *
         * getSession方法，什么时候创建session，什么时候查找session？
         *  如果客户端没有JSESSIONID，会创建session对象
         *  如果客户端有JSESSIONID，但是服务端已经没有session对象了，会创建session对象
         *
         *  客户端有JSESSIONID，并且服务端有对应session对象，才是查找session
         *
         */
        HttpSession session = request.getSession();
        System.out.println(session.getId());

        //向session域对象里保存一些数据
        session.setAttribute("product", "外星人笔记本");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
