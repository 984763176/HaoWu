package com.itheima.cookie;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class CookieUtils {

    /**
     * 根据Cookie的名称，获取对应的值
     * @param cookieName  要查找的Cookie的名称
     * @param request request对象
     * @return cookieName对应的值
     */
    public static String getCookieValue(String cookieName, HttpServletRequest request){
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                String name = cookie.getName();
                if(cookieName.equals(name)){
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
