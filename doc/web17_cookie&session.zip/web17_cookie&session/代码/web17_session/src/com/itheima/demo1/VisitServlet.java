package com.itheima.demo1;

import com.itheima.cookie.CookieUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(urlPatterns="/visit", name="VisitServlet")
public class VisitServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1. 保存本次访问时间到Cookie
        Date date = new Date();
        Cookie cookie = new Cookie("visit", date.getTime()+"");
        cookie.setMaxAge(10*24*60*60);
        response.addCookie(cookie);

        response.setContentType("text/html;charset=utf-8");
        //2. 获取上次访问时间 ，显示到页面上
        String visitStr = CookieUtils.getCookieValue("visit", request);
        if(visitStr!=null && !"".equals(visitStr)){
            //有上次访问时间，转换成日期格式，发送到页面显示
            date.setTime(Long.parseLong(visitStr));
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String lastVisit = format.format(date);
            response.getWriter().print("你上次访问时间是：" +  lastVisit);
        }else{
            //页面上显示：你是第一次访问
            response.getWriter().print("你是第一次访问");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}