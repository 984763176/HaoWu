package com.itheima.cookie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/createCookie", name="Demo01CookieCreateServlet")
public class Demo01CookieCreateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1. 创建一个Cookie对象，保存  username:zhangsan  在响应头里发送到客户端： Set-Cookie: username=zhangsan
        Cookie cookie = new Cookie("username", "zhangsan");

        //1.1 给Cookie设置有效期
        cookie.setMaxAge(10*60);

        //2. 把Cookie发送到客户端
        response.addCookie(cookie);

        Cookie cookie2 = new Cookie("age", "18");
        response.addCookie(cookie2);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}