package com.itheima.cookie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/recieveCookie2", name="Demo04CookieRecieveServlet")
public class Demo04CookieRecieveServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1. 接收客户端携带的Cookie。服务端只能接收Cookie的名称和value，没有其它数据。
        Cookie[] cookies = request.getCookies();
        /*if (cookies != null) {
            for (Cookie cookie : cookies) {
                String name = cookie.getName();
                String value = cookie.getValue();
                int maxAge = cookie.getMaxAge();

                System.out.println(name + ":  " + value +"  maxAge:" + maxAge);
            }
        }*/

        //获取名称为aa的Cookie
        /*if (cookies != null) {
            for (Cookie cookie : cookies) {
                String name = cookie.getName();
                if("aa".equalsIgnoreCase(name)){
                    String value = cookie.getValue();
                    System.out.println(value);
                    return;
                }
            }
        }*/

        String aa = CookieUtils.getCookieValue("aa", request);
        System.out.println(aa);

        //下面这种方式也能接收Cookie，但是需要自己手动解析，不推荐使用
        //String cookie = request.getHeader("Cookie");
        //System.out.println(cookie);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}