package com.itheima.session;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(urlPatterns="/getSession2", name="Demo02GetSessionServlet")
public class Demo02GetSessionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        System.out.println("getSession2里获取的session：" + session.getId());

        //Object product = session.getAttribute("product");
        //System.out.println("getSession2里获取的session：" + product);

        //销毁session对象
        session.invalidate();
        session = request.getSession();
        System.out.println("getSession2里销毁session后再获取：" + session.getId());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
