package com.itheima.cookie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/aa/createCookie", name="Demo02CookieCreateServlet")
public class Demo02CookieCreateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie cookie = new Cookie("validate", "validate");
        //设置有效路径：在整个web应用里任意资源都是有效路径
        cookie.setPath(request.getContextPath());

        //设置Cookie的有效域（了解）。.baidu.com 指在百度域名里资源才有效，比如：map.baidu.com, zhidao.baidu.com, wenku.baidu.com
        //cookie.setDomain(".baidu.com");

        response.addCookie(cookie);

        Cookie cookie1 = new Cookie("aa", "bb");
        cookie1.setPath(request.getContextPath());
        response.addCookie(cookie1);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}