package com.itheima.service;

import com.itheima.dao.UserDao;
import com.itheima.domain.User;

import java.util.List;

public class UserService {
    private UserDao dao = new UserDao();

    public List<User> findByPage(Integer pageNumber) {
        //1. 处理业务逻辑：把pageNumber，转换成SQL的limit需要的index值
        int index = (pageNumber - 1)*5;
        //2. 调用dao，查询数据
        List<User> userList = dao.findByPage(index);
        //3. 返回结果
        return userList;
    }

    public int calcPageCount() {
        //1. 查询总条数
        int totalCount = dao.findCount();
        //2. 根据总条数，和每页5条，计算分了多少页
        int pageCount = (int) Math.ceil(totalCount*1.0/5);
        //3. 返回结果
        return pageCount;
    }
}
