package com.itheima.web;

import com.itheima.domain.User;
import com.itheima.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns="/queryByPage", name="QueryUserByPageServlet")
public class QueryUserByPageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //准备第1项数据：指定页码的数据集合
        String pageNumberStr = request.getParameter("pageNumber");
        Integer pageNumber = 1;
        if (pageNumberStr != null && !"".equals(pageNumberStr)) {
            pageNumber = Integer.parseInt(pageNumberStr);
        }

        UserService service = new UserService();
        List<User> userList = service.findByPage(pageNumber);

        //准备第2项数据：总共分了多少页
        int pageCount = service.calcPageCount();

        //准备第3项数据：当前页码是多少，就是参数pageNumber

        //准备完成，把这三项数据传递到页面上
        request.setAttribute("userList", userList);
        request.setAttribute("pageCount", pageCount);
        request.setAttribute("pageNumber", pageNumber);
        request.getRequestDispatcher("/list.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
