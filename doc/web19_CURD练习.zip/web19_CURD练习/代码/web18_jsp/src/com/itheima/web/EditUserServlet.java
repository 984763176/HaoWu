package com.itheima.web;

import com.itheima.domain.User;
import com.itheima.service.UserService;
import com.itheima.util.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet(urlPatterns="/editUser", name="EditUserServlet")
public class EditUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        //1. 接收参数：map
        Map<String, String[]> map = request.getParameterMap();
        //2. 封装实体
        User user = BeanUtils.populate(map, User.class);
        //3. 处理业务请求，调用service，完成用户update操作
        UserService service = new UserService();
        service.edit(user);
        //4. 页面跳转
        response.sendRedirect(request.getContextPath()+"/queryAll");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}