package com.itheima.dao;

import com.itheima.domain.User;
import com.itheima.util.JdbcUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class UserDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JdbcUtils.getDataSource());

    public List<User> queryAll() {
        List<User> userList = jdbcTemplate.query("select * from tab_user", new BeanPropertyRowMapper<>(User.class));
        return userList;
    }

    public int addUser(User user) {
        String sql = "INSERT INTO tab_user (id, NAME, sex, age, address, qq, email) VALUES (?,?,?,?,?,?,?)";
        Object[] params = {user.getId(), user.getName(), user.getSex(), user.getAge(), user.getAddress(), user.getQq(), user.getEmail()};
        int update = jdbcTemplate.update(sql, params);
        return update;
    }

    public User findById(String id) {
        User user = jdbcTemplate.queryForObject("SELECT * FROM tab_user WHERE id = ?", new BeanPropertyRowMapper<>(User.class), id);
        return user;
    }

    public int editUser(User user) {
        String sql = "UPDATE tab_user SET sex = ?, age = ?, address= ?, qq = ?, email = ? WHERE id = ?";
        Object[] params = {user.getSex(), user.getAge(), user.getAddress(), user.getQq(), user.getEmail(), user.getId()};

        int update = jdbcTemplate.update(sql, params);
        return update;
    }

    public int deleteUser(String id) {
        int update = jdbcTemplate.update("delete from tab_user where id = ?", id);
        return update;
    }
}
