package com.itheima.service;

import com.itheima.dao.UserDao;
import com.itheima.domain.User;

import java.util.List;

public class UserService {
    private UserDao dao = new UserDao();

    public List<User> queryAll() {
        //处理业务逻辑：略
        //调用dao，查询所有用户
        List<User> userList = dao.queryAll();
        return userList;
    }

    public boolean addUser(User user) {
        int count = dao.addUser(user);
        return count==1;
    }

    public User findById(String id) {
        User user = dao.findById(id);
        return user;
    }

    public boolean edit(User user) {
        int count = dao.editUser(user);
        return count==1;
    }

    public boolean delete(String id) {
        int count = dao.deleteUser(id);
        return count==1;
    }
}
