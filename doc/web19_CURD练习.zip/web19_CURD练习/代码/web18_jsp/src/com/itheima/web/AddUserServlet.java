package com.itheima.web;

import com.itheima.domain.User;
import com.itheima.service.UserService;
import com.itheima.util.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet(urlPatterns="/addUser", name="AddUserServlet")
public class AddUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        //1.接收参数
        Map<String, String[]> map = request.getParameterMap();
        /*String name = request.getParameter("name");
        String sex = request.getParameter("sex");
        String age = request.getParameter("age");
        String address = request.getParameter("address");
        String qq = request.getParameter("qq");
        String email = request.getParameter("email");*/

        //2. 封装实体：
        /**
         * BeanUtils封装JavaBean的过程：map里的每一个key，找到JavaBean里对应的set方法，然后反射执行set方法，把value赋值给JavaBean的属性
         */
        User user = BeanUtils.populate(map, User.class);

        /*User user = new User();
        try {
            BeanUtils.populate(user, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }*/
        /*user.setName(name);
        user.setSex(sex);
        user.setAge(Integer.parseInt(age));
        user.setAddress(address);
        user.setQq(qq);
        user.setEmail(email);*/

        //3. 处理业务请求，调用service，完成添加用户的功能
        UserService service = new UserService();
        boolean success = service.addUser(user);

        //4. 页面跳转
        if (success) {
            //添加成功，重定向跳转到/queryAll
            response.sendRedirect(request.getContextPath() + "/queryAll");
        }else{
            //添加失败，重定向跳转回到添加页面（简单处理，不显示错误信息）
            response.sendRedirect(request.getContextPath() + "/add.jsp");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
