package com.itheima.service;

import com.itheima.dao.UserDao;
import com.itheima.domain.PageBean;
import com.itheima.domain.User;

import java.util.List;

public class UserService {
    private UserDao dao = new UserDao();

    public PageBean<User> queryByPage(Integer pageNumber) {
        PageBean<User> pageBean = new PageBean<User>();
        //1. 当前页的数据
        int index = (pageNumber -1) * 5;
        List<User> data = dao.findByPage(index);
        pageBean.setData(data);

        //2. 总共分了多少页
        int totalCount = dao.findCount();
        int pageCount = (int) Math.ceil(totalCount*1.0/5);
        pageBean.setPageCount(pageCount);
        //3. 当前是第几页
        pageBean.setPageNumber(pageNumber);

        //4. 非必须 总条数
        pageBean.setTotalCount(totalCount);
        //5. 非必须 每页几条
        pageBean.setPageSize(5);

        return pageBean;
    }
}
