package com.itheima.dao;

import com.itheima.domain.User;
import com.itheima.util.JdbcUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class UserDao {
    private JdbcTemplate jdbcTemplate = new JdbcTemplate(JdbcUtils.getDataSource());
    public List<User> findByPage(int index) {
        List<User> userList = jdbcTemplate.query("SELECT * FROM tab_user LIMIT ?, 5", new BeanPropertyRowMapper<>(User.class), index);
        return userList;
    }

    public int findCount() {
        Integer count = jdbcTemplate.queryForObject("select count(*) from tab_user", Integer.class);
        return count;
    }
}
