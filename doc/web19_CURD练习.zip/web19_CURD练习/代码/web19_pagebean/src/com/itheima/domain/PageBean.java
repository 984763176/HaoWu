package com.itheima.domain;

import java.util.List;

public class PageBean<T> {
    //1. 当前页的数据
    private List<T> data;
    //2. 总共分了多少页
    private int pageCount;
    //3. 当前是第几页
    private int pageNumber;

    //4. 非必须 总条数
    private int totalCount;
    //5. 非必须 每页几条
    private int pageSize;

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
