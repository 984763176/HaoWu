package com.itheima.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/demo04", loadOnStartup = 3, initParams = {
        @WebInitParam(name = "a", value = "A"),
        @WebInitParam(name = "b", value = "B")
})
/*@WebServlet(urlPatterns = "/aa/*")*/
/*@WebServlet(urlPatterns = "*.do")*/
/*@WebServlet(urlPatterns = "/*.do")*/
public class Demo04ConfigServlet extends HttpServlet {

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        System.out.println("Demo04ConfigServlet对象创建了");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Demo04ConfigServlet running......");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
