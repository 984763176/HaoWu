package com.itheima.servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;

/**
 * Servlet类：是由服务器软件创建对象，并由服务器软件调用执行Servlet的方法
 */
@WebServlet(urlPatterns = "/demo01",name = "dem01", initParams = {
        @WebInitParam(name="aa",value = "bb")
})
public class Demo01APIServlet implements Servlet {

    /**
     * 初始化方法。
     * 由服务器软件调用，服务器软件创建Servlet对象之后调用一次
     * @param servletConfig
     * @throws ServletException
     */
    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        System.out.println("Demo01APIServlet.init......");

        /**
         * 参数ServletConfig：是当前Servlet的配置信息对象。
         * 是由服务器软件在执行init方法的时候，创建并传递进来的，里边维护了：
         * 1. 当前Servlet的名称。注解里配置的name属性值
         * 2. 当前Servlet的初始化参数。注解里配置的initParams属性值
         * 3. 当前web应用的ServletContext对象。
         */
        //1. 获取当前Servlet的名称
        String servletName = servletConfig.getServletName();
        System.out.println("Servlet的名称："+ servletName);
        //2. 获取当前Servlet的初始化参数
        String aa = servletConfig.getInitParameter("aa");
        System.out.println("Servlet的初始化参数aa：" +aa);
        //3. 获取当前web应用的ServletContext对象
        ServletContext servletContext = servletConfig.getServletContext();
        System.out.println("ServletContext:" + servletContext);
    }

    /**
     * service：提供业务处理的方法
     * @param servletRequest
     * @param servletResponse
     * @throws ServletException
     * @throws IOException
     */
    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        System.out.println("Demo01APIServlet.service......");

        /**
         * 参数ServletRequest：
         *  代表客户端的请求，我们可以从这个参数里获取客户端提交的数据，例如：页面表单提交的数据。
         *  String username = servletRequest.getParameter("username");
         *  获取表单提交的name为username的表单项的值
         *
         *
         * 参数ServletResponse：
         *  代表服务端向客户端发送的响应数据，我们可以向这个对象里设置一些数据，这些数据会被发送到浏览器
         *  servletResponse.getWriter().print("hello");
         *   向浏览器页面上发送数据
         */
        String username = servletRequest.getParameter("username");
        System.out.println(username);

        servletResponse.getWriter().print("hello");
    }

    /**
     * 销毁方法。
     * 当服务器软件销毁Servlet对象的时候，会调用一次destory方法
     */
    @Override
    public void destroy() {
        System.out.println("Demo01APIServlet.destory......");
    }

    @Override
    public ServletConfig getServletConfig() {
        return null;
    }

    @Override
    public String getServletInfo() {
        return null;
    }
}
