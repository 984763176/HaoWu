package com.itheima.req;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;

@WebServlet(urlPatterns="/header", name="Demo02RequestHeaderServlet")
public class Demo02RequestHeaderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取请求头
        String host = request.getHeader("Host");
        System.out.println(host);


        String userAgent = request.getHeader("User-Agent");
        System.out.println(userAgent);

        //获取请求头Referer：请求是从哪个页面上发起的，可以用来防止盗链。
        String referer = request.getHeader("Referer");
        System.out.println(referer);

        System.out.println("----------------------------------");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headerValue = request.getHeader(headerName);
            System.out.println(headerName + " : " + headerValue);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}