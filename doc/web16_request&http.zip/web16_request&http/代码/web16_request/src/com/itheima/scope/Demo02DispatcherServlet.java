package com.itheima.scope;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/dispatcher", name="Demo02DispatcherServlet")
public class Demo02DispatcherServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Object loginInfo = request.getAttribute("loginInfo");
        System.out.println("Demo02DispatcherServlet里获取request域的loginInfo：" +loginInfo);
        response.getWriter().print("Demo02DispatcherServlet");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
