package com.itheima.req;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/param2", name="Demo01RequestParam2Servlet")
public class Demo01RequestParam2Servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        /**
         * 获取中文参数乱码（post方式）：所有乱码的原因 ，都是编码和解码方式不一致导致的
         * 乱码的原因：
         *      页面是使用utf-8编码；reuqest默认使用iso-8859-1解码的
         * 解决的方案：
         *      设置request使用utf-8解码
         *      request.setCharacterEncoding("utf-8") ---必须要加在所有的获取参数代码之前
         *
         */
        request.setCharacterEncoding("utf-8");
        String username = request.getParameter("username");
        String method = request.getMethod();

        System.out.println("请求方式：" + method + ", 获取表单参数：" + username);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}