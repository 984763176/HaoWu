package com.itheima.scope;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/scope", name="Demo01ScopeServlet")
public class Demo01ScopeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //向request域对象里存取数据
        request.setAttribute("loginInfo", "用户名或密码错误");
        //从request域对象里取出数据
        Object loginInfo = request.getAttribute("loginInfo");
        System.out.println(loginInfo);


        //请求转发到/dispatcher
        //RequestDispatcher dispatcher = request.getRequestDispatcher("/dispatcher");
        //执行转发
        //dispatcher.forward(request, response);

        request.getRequestDispatcher("/dispatcher").forward(request, response);

        //重定向到/dispacher
        //response.sendRedirect(request.getContextPath() + "/dispatcher");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}