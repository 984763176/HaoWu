package com.itheima.req;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/line", name="Demo01RequestLineServlet")
public class Demo01RequestLineServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取请求行的数据
        //请求方式：目前只有form的method指定为post，才是post方式；Ajax里指定post方式是post； 其它都是get方式
        String method = request.getMethod();
        System.out.println("请求方式：" + method);

        //获取请求资源
        String requestURI = request.getRequestURI();
        StringBuffer requestURL = request.getRequestURL();
        System.out.println("requestURI:" + requestURI);
        System.out.println("reuqestURL:" + requestURL);

        //获取web应用的context path
        String contextPath = request.getContextPath();
        System.out.println("contextPath:" + contextPath);

        //response.sendRedirect(contextPath + "/method.html");

        //获取客户端的ip地址
        String remoteAddr = request.getRemoteAddr();
        System.out.println("客户端的IP：" + remoteAddr);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}