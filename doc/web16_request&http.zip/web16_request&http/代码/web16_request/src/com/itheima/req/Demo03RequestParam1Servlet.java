package com.itheima.req;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

@WebServlet(urlPatterns="/param1", name="Demo03RequestParam1Servlet")
public class Demo03RequestParam1Servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取表单参数：username
        String username = request.getParameter("username");
        System.out.println(username);

        //获取表单多值参数
        String[] hobbies = request.getParameterValues("hobby");

        if (hobbies != null) {
            for (int i = 0; i < hobbies.length; i++) {
                System.out.println(hobbies[i]);
            }
        }

        System.out.println("-------------------------------");
        //获取所有表单参数，以Map接收。Map的key：是表单项的name；Map的value：是表单的值
        Map<String, String[]> map = request.getParameterMap();
        for (Map.Entry<String, String[]> entry : map.entrySet()) {
            String name = entry.getKey();
            String[] values = entry.getValue();
            System.out.println(name + ":" + Arrays.toString(values));
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
