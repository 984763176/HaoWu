package com.itheima.anno;

import java.util.Date;

/**
 * JDK提供的一些注解
 * @author liuyp
 * @version 1.0
 */
@SuppressWarnings("all")
public class Demo01JdkAnno implements Man{

    public static void main(String[] args) {
        Date date = new Date();
        int year = date.getYear();
        System.out.println(year);

        Demo01JdkAnno demo01 = new Demo01JdkAnno();
        demo01.eat();

        String str = "hello";
    }

    /**
     * 重写父类的toString方法
     * @return
     */
    @Override
    public String toString() {
        return "重写父类的方法";
    }

    @Deprecated
    @Override
    public void eat() {

    }
}

interface Man{
    public void eat();
}
