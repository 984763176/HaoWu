package com.itheima.anno;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 自定义注解的解析类
 */
public class MyAnnoParser {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
        /**
         * 判断MyAnnoTest类的sleep方法 上是否有MyAnno注解
         */
        //1. 获取Class对象
        Class<?> clazz = Class.forName("com.itheima.anno.MyAnnoTest");
        //2. 获取sleep方法对象
        Method sleepMethod = clazz.getMethod("sleep");

        //3. 判断方法上是否有MyAnno注解。如果有这个注解，就执行这个方法；否则不执行
        boolean present = sleepMethod.isAnnotationPresent(MyAnno.class);
        if (present) {
            //方法上有MyAnno注解，再判断注解值。如果name属性值是jerry，就执行这个方法；否则不执行
            MyAnno myAnno = sleepMethod.getAnnotation(MyAnno.class);
            String name = myAnno.name();
            if("jerry".equals(name)){
                sleepMethod.invoke(clazz.newInstance());
            }else{
                System.out.println("方法上注解的name值不是jerry，所以不执行");
            }

        }else{
            //方法上没有MyAnno注解，不执行，并打印一句话
            System.out.println("方法上没有@MyAnno，不执行");
        }
    }
}
