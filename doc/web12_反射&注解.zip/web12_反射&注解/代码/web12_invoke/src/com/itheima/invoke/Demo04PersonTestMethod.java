package com.itheima.invoke;

import org.junit.Test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 通过反射操作Method方法对象
 */
public class Demo04PersonTestMethod {

    /**
     * 获取public类型的eat方法，无参
     */
    @Test
    public void demo1() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
        //1. 获取Class字节码对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 获取eat方法对象Method
        Method eatMethod = clazz.getMethod("eat");

        System.out.println(eatMethod);

        Object obj = clazz.newInstance();
        //3. 通过反射操作eat方法对象
        Object result = eatMethod.invoke(obj);
        System.out.println("eat方法执行返回值是：" +result);
    }

    /**
     * 获取private类型的sing方法，有参
     * @throws ClassNotFoundException
     * @throws NoSuchMethodException
     */
    @Test
    public void demo2() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
        //1. 获取Class字节码对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 获取sing方法对象Method
        Method singMethod = clazz.getDeclaredMethod("sing", String.class);
        System.out.println(singMethod);

        //设置方法允许暴力反射执行
        singMethod.setAccessible(true);

        Object obj = clazz.newInstance();
        //3. 通过反射操作sing方法对象
        Object result = singMethod.invoke(obj, "绿光");
        System.out.println("sing方法的返回值是：" + result);
    }

    /**
     * 批量获取类里的Method对象
     * @throws ClassNotFoundException
     * @throws NoSuchMethodException
     */
    @Test
    public void demo3()throws ClassNotFoundException, NoSuchMethodException {
        //1. 获取Class字节码对象
        Class clazz = Class.forName("com.itheima.invoke.Person");

        //2. 获取所有public类型的方法Method对象
        //Method[] methods = clazz.getMethods();

        //3. 获取所有的方法Method对象，无论是public还是private
        Method[] methods = clazz.getDeclaredMethods();

        for (int i = 0; i < methods.length; i++) {
            System.out.println(methods[i]);
        }
    }

}
