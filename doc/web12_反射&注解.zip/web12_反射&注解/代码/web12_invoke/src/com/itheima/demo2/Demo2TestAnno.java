package com.itheima.demo2;

import org.junit.Test;

public class Demo2TestAnno {

    /**
     * Test注解的要求：
     * 要求方法是void，无参方法，public类型
     */
    @Test
    public void demo1(){
        System.out.println("demo1()....");
    }

    @MyTest
    public void demo2(){
        System.out.println("demo2()....");
    }
}
