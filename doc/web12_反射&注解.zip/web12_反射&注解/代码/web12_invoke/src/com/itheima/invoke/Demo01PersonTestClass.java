package com.itheima.invoke;

import org.junit.Test;

/**
 * 调用Person对象的方法
 */
public class Demo01PersonTestClass {

    /**
     * 正常调用Person的内容
     */
    @Test
    public void demo1(){
        Person p = new Person();
        p.eat();
    }

    /**
     * 获取Class对象一：通过类名.class
     */
    @Test
    public void demo2(){
        Class clazz = Person.class;
        System.out.println(clazz);
    }

    /**
     * 获取Class对象二：通过对象.getClass()
     */
    @Test
    public void demo3(){
        Person p = new Person();
        Class<? extends Person> clazz = p.getClass();
        System.out.println(clazz);
    }

    /**
     * 获取Class对象三：通过Class.forName()静态方法获取
     */
    @Test
    public void demo4() throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        Class clazz = Class.forName("com.itheima.invoke.Person");
        System.out.println(clazz);

        //获取类的名称
        String clazzName = clazz.getName();
        System.out.println("类名称：" +clazzName);
        //创建类的实例对象 newInstance() 调用无参构造，创建一个实例对象出来
        Object obj = clazz.newInstance();
        ((Person)obj).eat();
    }
}
