package com.itheima.invoke;

public class Person {
    private String name;
    public Integer age;

    public Person() {
    }
    public Person(String name, Integer age) {
        this.name = name;
        this.age = age;
    }

    public void eat(){
        System.out.println("吃2碗");
    }

    private String sing(String song){
        System.out.println("唱歌:" + song);
        return "唱歌" + song;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
