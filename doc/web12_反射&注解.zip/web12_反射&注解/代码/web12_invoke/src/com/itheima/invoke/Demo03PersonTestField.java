package com.itheima.invoke;

import org.junit.Test;

import java.lang.reflect.Field;

/**
 * 反射操作类的属性Field
 */
public class Demo03PersonTestField {

    /**
     * 获取public类型的age属性
     */
    @Test
    public void demo1() throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, InstantiationException {
        //1. 获取类的Class对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 获取类的属性Field对象：age
        Field ageFiled = clazz.getField("age");
        System.out.println(ageFiled);

        Object obj = clazz.newInstance();
        //3. 设置age属性的值
        ageFiled.set(obj, 20);
        //4. 获取age属性的值
        Object o = ageFiled.get(obj);
        System.out.println("obj对象的age属性值：" + o);

        //5. 获取age属性的类型
        Class<?> type = ageFiled.getType();
        System.out.println("age属性的类型是：" + type);
    }

    /**
     * 获取private类型的属性Field对象
     * @throws ClassNotFoundException
     * @throws NoSuchFieldException
     */
    @Test
    public void demo2() throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, InstantiationException {
        //1. 获取类的Class对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 获取类的属性Field对象：name，private
        Field nameFiled = clazz.getDeclaredField("name");
        System.out.println(nameFiled);

        //设置属性允许暴力反射
        nameFiled.setAccessible(true);


        Object obj = clazz.newInstance();
        //3. 设置name属性值
        nameFiled.set(obj, "zhangsan");
        //4. 获取name属性值
        Object value = nameFiled.get(obj);
        System.out.println("obj对象里name属性值：" + value);

        //5. 获取name属性的类型
        Class<?> type = nameFiled.getType();
        System.out.println("name属性的类型是：" + type);
    }

    @Test
    public void demo3()throws ClassNotFoundException, NoSuchFieldException {
        //1. 获取类的Class对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 获取类的属性Field对象
        Field[] fields = clazz.getFields();
        for (int i = 0; i < fields.length; i++) {
            System.out.println(fields[i]);
        }
    }

    @Test
    public void demo4()throws ClassNotFoundException, NoSuchFieldException {
        //1. 获取类的Class对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 获取类的属性Field对象
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            System.out.println(fields[i]);
        }
    }
}
