package com.itheima.anno;

/*@MyAnno*/
public class MyAnnoTest {

    /*@MyAnno*/
    private String name;

    /*@MyAnno(age = 20, address = "广东深圳", name = "jerry")*/
    @MyAnno(value="aaa", name = "jerry")
    /*@MyAnno({"aa","bb"})*/
    public void sleep(){
        /*@MyAnno*/
        String email = "aa@163.com";

        System.out.println("睡");
    }

    public static void main(String[] args) {
        MyAnnoTest t = new MyAnnoTest();
        t.sleep();
    }
}
