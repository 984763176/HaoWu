package com.itheima.demo1;

import java.lang.reflect.Field;
import java.util.Enumeration;
import java.util.ResourceBundle;

public class Demo01Man {

    /**
     * 要求：读取src下man.properties里的信息，转换成一个Man对象
     * @param args
     */
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchFieldException {
        //1. 读取man.properties配置文件里的数据：使用ResourceBundle读取properties文件，从src下读取，只需要给文件名称，不需要后缀名

        ResourceBundle bundle = ResourceBundle.getBundle("man");
        /*Enumeration<String> keys = bundle.getKeys();
        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
        }*/
        //2. 使用反射，把每一项数据封装到Man对象里。第一步：要先创建一个实例对象；然后才通过反射设置属性值
       //2.1 加载className指定的类，得到字节码对象
        String className = bundle.getString("className");

        Class<?> clazz = Class.forName(className);

        //2.2. 创建类的实例
        Object obj = clazz.newInstance();

        //2.3 分别给类的每个属性赋值，循环配置文件里所有 key
        Enumeration<String> keys = bundle.getKeys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            //如果key是className，continue
            if("className".equalsIgnoreCase(key)){
                continue;
            }

            //每一个key，对应类的一个属性。key是属性名称，获取到属性的Field对象
            Field field = clazz.getDeclaredField(key);
            //通过反射给field赋值
            field.setAccessible(true);
            //判断属性的类型
            Class<?> type = field.getType();
            String value = bundle.getString(key);
            if(type==Integer.class){
                field.set(obj, Integer.parseInt(value));
            }else{
                field.set(obj, value);
            }
        }

        System.out.println("通过反射，把man.properties文件转换成对象：" +obj);

    }
}
