package com.itheima.demo2;

import java.lang.reflect.Method;

public class MyTestParser {
    public static void main(String[] args) throws Exception {
        String methodName = "demo2";
        String className = "com.itheima.demo2.Demo2TestAnno";

        //1. 获取类的字节码对象
        Class<?> clazz = Class.forName(className);
        //2. 获取方法对象
        Method method = clazz.getMethod(methodName);
        //3. 判断方法上是否有@MyTest注解
        boolean present = method.isAnnotationPresent(MyTest.class);
        //4. 如果有，执行这个方法
        if (present) {
            method.invoke(clazz.newInstance());
        }
    }
}
