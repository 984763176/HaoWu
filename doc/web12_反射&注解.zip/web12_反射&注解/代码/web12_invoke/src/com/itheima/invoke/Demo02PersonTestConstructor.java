package com.itheima.invoke;

import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * 反射操作构造方法对象Constructor
 */
public class Demo02PersonTestConstructor {

    /**
     * 获取无参的构造方法
     */
    @Test
    public void demo1() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        //1. 获取字节码对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 从Class对象中获取构造方法对象
        Constructor constructor = clazz.getConstructor();

        System.out.println(constructor);

        //3. 调用无参Constructor，创建实例
        Person obj = (Person) constructor.newInstance();
        obj.eat();
    }


    @Test
    public void demo2() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        //1. 获取字节码对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 从Class对象中获取构造方法对象：String，Integer
        Constructor constructor = clazz.getConstructor(String.class, Integer.class);

        System.out.println(constructor);

        //3. 调用有参Constructor，创建实例
        Person p = (Person) constructor.newInstance("tom", 20);
        System.out.println("创建的实例名称是：" + p.getName());
    }

    /**
     * 获取私有的构造方法对象
     * @throws ClassNotFoundException
     * @throws NoSuchMethodException
     */
    @Test
    public void demo3() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        //1. 获取字节码对象
        Class clazz = Class.forName("com.itheima.invoke.Person");
        //2. 从Class对象中获取构造方法对象：String，Integer
        Constructor constructor = clazz.getDeclaredConstructor(String.class, Integer.class);

        System.out.println(constructor);

        //3. 设置构造方法允许暴力反射执行
        constructor.setAccessible(true);

        Person p = (Person) constructor.newInstance("jerry", 19);
        System.out.println("创建的实例名称是：" + p.getName());
    }
}
