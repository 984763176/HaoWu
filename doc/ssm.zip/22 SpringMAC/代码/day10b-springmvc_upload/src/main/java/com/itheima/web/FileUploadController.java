package com.itheima.web;


import com.itheima.utils.UploadUtils;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

@Controller
@RequestMapping("/springmvc")
public class FileUploadController {

    @RequestMapping("/upload01")
    public String upload01(HttpServletRequest request) throws IOException {
        //String upload = request.getParameter("upload");
        //String desc = request.getParameter("desc");
        //System.out.println("upload="+upload);
        //System.out.println("desc="+desc);
        //is就是在前端里面传递过来的所有的数据流(文件名字,文件内容, 其它的字段的值[文件的描述])
        InputStream is = request.getInputStream();
        //1.把is转成字符串
        //2.发现规律, 截取字符串, 获得文件的名字, 获得文件的内容, 获得其它字段的值
        //3.再把文件的内容转成输出流, 存到服务器
        return  "success";
    }


    @RequestMapping("/upload02")
    //upload对象:就是SpringMVC帮我们封装的文件对象(包含了文件的名字,文件的内容....)
    public String upload02(MultipartFile upload, String desc, HttpSession session) throws IOException {
        //1.获得文件名
        String filename = upload.getOriginalFilename();
        System.out.println("文件描述desc="+desc);

        //2.获得文件的UUID名字
        String uuidName = UploadUtils.getUUIDName(filename);

        //3. 获得服务器里面的upload的绝对路径
        String realPath = session.getServletContext().getRealPath("/upload");

        //4.随机获得两层目录 /A/C
        String dir = UploadUtils.getDir();
        //创建两层目录
        File fileDir = new File(realPath, dir);
        if(!fileDir.exists()){
            fileDir.mkdirs();
        }

        //5.fileDir  /upload/A/C
        File outFile = new File(fileDir, uuidName);

        //4.upload输出到outFile文件里面
        upload.transferTo(outFile);

        return  "success";
    }


    @RequestMapping("/upload03")
    //upload对象:就是SpringMVC帮我们封装的文件对象(包含了文件的名字,文件的内容....)
    public String upload03(MultipartFile upload, String desc) throws IOException {
        //另外服务器的地址
        String IMG_SERVER_PATH = "http://localhost:9090/upload/";

        //1.获得文件名
        String filename = upload.getOriginalFilename();
        System.out.println("文件描述desc="+desc);

        //2.获得文件的UUID名字
        String uuidName = UploadUtils.getUUIDName(filename);

        //3. 创建Client对象(jersey里面)
        Client client = Client.create();
        //4.根据IMG_SERVER_PATH和uuidName 获得Resource对象
        WebResource resource = client.resource(IMG_SERVER_PATH + uuidName);

        //5.把原始文件upload, 和resource关联, 进行上传
        resource.put(upload.getBytes());
        return  "success";
    }




}
