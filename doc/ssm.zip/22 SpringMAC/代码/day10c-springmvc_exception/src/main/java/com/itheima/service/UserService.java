package com.itheima.service;

import com.itheima.dao.UserDao;

public class UserService {

    public void regist() {
        System.out.println("UserService...");
        UserDao userDao = new UserDao();
        userDao.save();

        int i = 1/0; //不可预期

    }
}
