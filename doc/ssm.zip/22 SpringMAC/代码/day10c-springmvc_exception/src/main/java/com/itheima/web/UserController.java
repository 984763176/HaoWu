package com.itheima.web;

import com.itheima.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 1. 自定义异常类(封装异常信息) Exception Throwable 子类
 * 2. 自定义异常处理器
 * 3. 配置异常处理器(注册)
 */

@Controller
@RequestMapping("/user")
public class UserController {

    @RequestMapping("/regist")
    public  String regist(){
        //try {
            System.out.println("regist()..");
            UserService userService = new UserService();
            userService.regist();
       /* } catch (Exception e) {
            e.printStackTrace();

        }*/
        return  "success";
    }

    @RequestMapping("/regist")
    public  String findAll(){
        //try {
        System.out.println("regist()..");
        UserService userService = new UserService();
        userService.regist();
       /* } catch (Exception e) {
            e.printStackTrace();

        }*/
        return  "success";
    }

}
