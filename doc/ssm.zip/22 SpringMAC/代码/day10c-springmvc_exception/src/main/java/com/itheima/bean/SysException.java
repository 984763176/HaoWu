package com.itheima.bean;

/**
 * 自定义异常
 */
public class SysException extends  Exception {

    private String msg; //异常的信息

    public SysException() {
    }


    public SysException( String msg) {
        this.msg = msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }
}
