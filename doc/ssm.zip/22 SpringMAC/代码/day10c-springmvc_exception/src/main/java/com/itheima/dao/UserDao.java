package com.itheima.dao;

public class UserDao {

    public void save() {
        System.out.println("UserDao...");
    }
}
