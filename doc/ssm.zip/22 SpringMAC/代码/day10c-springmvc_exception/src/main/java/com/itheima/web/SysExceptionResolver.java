package com.itheima.web;

import com.itheima.bean.SysException;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义异常处理器
 */
public class SysExceptionResolver implements HandlerExceptionResolver {

    @Nullable
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
        SysException sysException = null;
        //判断ex是否是SysException类型
        if(ex instanceof SysException){
            sysException= (SysException) ex;
        }else{
            sysException = new SysException(ex.getMessage());
        }

        //响应
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("msg",sysException.getMsg()); //获得异常信息,存到了域里面
        modelAndView.setViewName("msg");
        return modelAndView;
    }
}
