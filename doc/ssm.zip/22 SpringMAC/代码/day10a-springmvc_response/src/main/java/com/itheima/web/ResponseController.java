package com.itheima.web;


import com.itheima.bean.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@RequestMapping("/response")
public class ResponseController {

    //***********************一,方法的返回值******************************************************
    @RequestMapping("/testReturnString")
    //测试返回String类型
    public String testReturnString(){
        System.out.println("testReturnString()收到了请求...");
        //"success": //逻辑视图
        // /WEB-INF/pages/success.jsp: 物理视图
        return  "success";
    }

    @RequestMapping("/testReturnVoid")
    //测试返回void类型
    //1.方法的参数没有HttpResponse的情况, 响应的结果找到 /类上面的RequestMapping/方法上的RequestMapping 结果响应
    //2.方法的参数没有HttpResponse的情况, 需要自己来处理响应(可以转发,也可以重定向)
    public void testReturnVoid( HttpServletRequest request,HttpServletResponse response) throws IOException {
        System.out.println("testReturnVoid()收到了请求...");
        response.sendRedirect(request.getContextPath()+"/redirectPage.jsp");
        //request.getRequestDispatcher("").forward(request,response);

    }

    @RequestMapping("/testModelAndView")
    //测试返回ModelAndView类型
    public ModelAndView testModelAndView() {
        System.out.println("testModelAndView()收到了请求...");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("msg","hello..."); //相当于向request域里面存了msg
        modelAndView.setViewName("success");//设置逻辑视图的名字
        return  modelAndView;
    }


    //***********************二,转发和重定向******************************************************
    @RequestMapping("/forwardToPage")
    //转发到页面
    public String forwardToPage() {
        System.out.println("forwardToPage() 收到了请求...");
        //return  "success"; 逻辑视图
        return  "forward:/WEB-INF/pages/success.jsp";  //forward不能写逻辑视图,必须写物理视图
    }

    @RequestMapping("/forwardToOtherController")
    //转发到其它的Controller方法(可是是不同的Controller类)
    public String forwardToOtherController() {
        System.out.println("forwardToOtherController() 收到了请求...");
        return  "forward:/response/testModelAndView";  //: /类上面的RequestMapping/方法上的RequestMapping;
    }

    @RequestMapping("/redirectToPage")
    //重定向到页面; WEB-INF里面的资源是收保护的 外界不可以直接访问(浏览器直接返回,重定向)
    public String redirectToPage() {
        System.out.println("redirectToPage() 收到了请求...");
        return  "redirect:/redirectPage.jsp";  //redirect不能写逻辑视图,必须写物理视图
    }

    @RequestMapping("/redirectToOtherController")
    //重定向到其它的Controller方法(可是是不同的Controller类)
    public String redirectToOtherController() {
        System.out.println("redirectToOtherController() 收到了请求...");
        return  "redirect:/response/testModelAndView";  //: /类上面的RequestMapping/方法上的RequestMapping;
    }

    //***********************三,响应json******************************************************

    //响应json
    //1.定义方法 return对象, 在方法加上@ResponseBody
    //2. 导入jackson坐标(SpringMVC默认支持jackson)
    @RequestMapping("/testJson")
   // public @ResponseBody User testJson(String name, int age) {
    public @ResponseBody User testJson(User user02) {
        //System.out.println("name="+name);
        //System.out.println("age="+age);
        System.out.println(user02);

        //模拟调用业务 List User Map
        User user = new User();
        user.setUsername("zs");
        user.setPassword("123456");
        user.setAge(18);
        return  user;
    }






}
