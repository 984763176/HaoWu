package com.itheima.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
@RequestMapping("/user")
public class UserController {
    @RequestMapping("/regist")
    public  String regist(){
        System.out.println("regist()执行了....");
        return  "success";
    }

    @RequestMapping("/findAll")
    public  String findAll(){
        System.out.println("findAll()执行了....");
        return  "success";
    }

}
