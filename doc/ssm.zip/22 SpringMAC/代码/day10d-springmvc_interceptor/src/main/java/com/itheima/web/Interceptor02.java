package com.itheima.web;

import org.springframework.lang.Nullable;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 1. 定义一个类实现HandlerInterceptor
 * 2. 在springmvc.xml配置拦截器
 */
public class Interceptor02 implements HandlerInterceptor {

    @Override
    //在Controller的方法执行之前执行
    //返回值: true 就放行
    //返回值: false 拦截了
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("Interceptor02 preHandle()...");
        //判断用户是否登录过, 没有登录过, 返回false, 跳转到登录页面
        //登录过了, 返回true,放行, 让请求
       //return false;
        return  true;
    }

    @Override
    //在Controller的方法执行之后, 在视图渲染之前执行
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {
        System.out.println("Interceptor02 postHandle()...");
    }

    @Override
    //在 在视图渲染之后执行
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {
        System.out.println("Interceptor02 afterCompletion()...");
    }
}
