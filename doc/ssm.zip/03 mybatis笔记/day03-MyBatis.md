---
typora-copy-images-to: img
---

# day03-MyBatis

## 学习目标

+ 理解Mybatis连接池与事务操作
+ 掌握Mybatis动态SQL
+ 掌握Mybatis多表关联查询
+ 掌握Mybatis多表关联查询



## 一,Mybatis 连接池与事务深入 

### 1.Mybatis 的连接池技术 

​	我们在前面的 WEB 课程中也学习过类似的连接池技术，而在 Mybatis 中也有连接池技术，但是它采用的是自己的连接池技术 。在 Mybatis 的 SqlMapConfig.xml 配置文件中， 通过  `<dataSource type=”pooled”>`来实现 Mybatis 中连接池的配置.

#### 1.1Mybatis 连接池的分类 

+ 在 Mybatis 中我们将它的数据源 dataSource 分为以下几类 

![img](img/tu_1.png)

+ 可以看出 Mybatis 将它自己的数据源分为三类：

  +  UNPOOLED 不使用连接池的数据源
  +  POOLED 使用连接池的数据源
  +  JNDI 使用 JNDI 实现的数据源,不要的服务器获得的DataSource是不一样的. 注意: 只有是web项目或者Maven的war工程, 才能使用. 我们用的是tomcat, 用的连接池是dbcp.

  ![img](img/tu_2.png)

+ 在这三种数据源中，我们目前阶段一般采用的是 POOLED 数据源（很多时候我们所说的数据源就是为了更好的管理数据库连接，也就是我们所说的连接池技术）,等后续学了Spring之后,会整合一些第三方连接池。 

#### 1.2Mybatis 中数据源的配置 

+ 我们的数据源配置就是在 SqlMapConfig.xml 文件中， 具体配置如下： 

  ![img](img/tu_3.png)

+ MyBatis 在初始化时，解析此文件，根据<dataSource>的 type 属性来创建相应类型的的数据源DataSource，即：

  ​	type=”POOLED”： MyBatis 会创建 PooledDataSource 实例
  ​	type=”UNPOOLED” ： MyBatis 会创建 UnpooledDataSource 实例
  ​	type=”JNDI”： MyBatis 会从 JNDI 服务上查找 DataSource 实例，然后返回使用.

#### 1.3Mybatis 中 DataSource 配置分析 

+ 代码,在21行加一个断点, 当代码执行到21行时候,我们根据不同的配置(POOLED和UNPOOLED)来分析DataSource

![1533783469075](img/1533783469075.png)

+ 当配置文件配置的是type=”POOLED”, 可以看到数据源连接信息

  ![1533783591235](img/1533783591235.png)



+ 当配置文件配置的是type=”UNPOOLED”, 没有使用连接池

  ![1533783672422](img/1533783672422.png)

### 2.Mybatis 的事务控制 

#### 2.1JDBC 中事务的回顾 

​	在 JDBC 中我们可以通过手动方式将事务的提交改为手动方式，通过 setAutoCommit()方法就可以调整。通过 JDK 文档，我们找到该方法如下： 

![img](img/tu_8.png)

​	那么我们的 Mybatis 框架因为是对 JDBC 的封装，所以 Mybatis 框架的事务控制方式，本身也是用 JDBC的 setAutoCommit()方法来设置事务提交方式的。 

#### 2.2Mybatis 中事务提交方式 

+ Mybatis 中事务的提交方式，本质上就是调用 JDBC 的 setAutoCommit()来实现事务控制。我们运行之前所写的代码： 

![img](img/tu_9.png)

+ userDao 所调用的 saveUser()方法如下： 

  ![img](img/tu_10.png)

+ 观察在它在控制台输出的结果： 

  ![img](img/tu_11.png)

  ​	这是我们的 Connection 的整个变化过程， 通过分析我们能够发现之前的 CUD操作过程中，我们都要手动进行事务的提交，原因是 setAutoCommit()方法，在执行时它的值被设置为 false 了，所以我们在CUD 操作中，必须通过 sqlSession.commit()方法来执行提交操作。 

#### 2.3 Mybatis 自动提交事务的设置 

​	通过上面的研究和分析，现在我们一起思考，为什么 CUD 过程中必须使用 sqlSession.commit()提交事务？主要原因就是在连接池中取出的连接，都会将调用 connection.setAutoCommit(false)方法，这样我们就必须使用 sqlSession.commit()方法，相当于使用了 JDBC 中的 connection.commit()方法实现事务提交。明白这一点后，我们现在一起尝试不进行手动提交，一样实现 CUD 操作。 

![img](img/tu_12.png)

​	我们发现，此时事务就设置为自动提交了，同样可以实现 CUD 操作时记录的保存。虽然这也是一种方式，但就编程而言，设置为自动提交方式为 false 再根据情况决定是否进行提交，这种方式更常用。因为我们可以根据业务情况来决定提交是否进行提交。 

## 二,Mybatis 映射文件的 SQL 深入 

​	Mybatis 的映射文件中，前面我们的 SQL 都是比较简单的，有些时候业务逻辑复杂时，我们的 SQL是动态变化的，此时在前面的学习中我们的 SQL 就不能满足要求了。

### 1.动态 SQL 之<if>标签 

​	我们根据实体类的不同取值，使用不同的 SQL 语句来进行查询。比如在 id 如果不为空时可以根据 id查询，如果 username 不同空时还要加入用户名作为条件。这种情况在我们的多条件组合查询中经常会碰到。 



+ QueryVo.java

```java
public class QueryVo {
    private User user;
}
```

+ UserDao.java

```java
public interface UserDao {
    /**
     * 复杂参数查询
     * @return
     */
    List<User> findByQueryVo(QueryVo queryVo);
}

```

+ UserDao.xml

![1533787197585](img/1533787197585.png)



+ 测试

```java
    @Test
    public void fun01() throws Exception {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        QueryVo queryVo = new QueryVo();
        User user = new User();
        user.setUid(8);
        user.setUsername("王%");
        queryVo.setUser(user);

        List<User> list = userDao.findByQueryVo(queryVo);
        System.out.println(list);

        sqlSession.close();
    }
```

### 2.动态 SQL 之<where>标签 

为了简化上面 where 1=1 的条件拼装，我们可以采用<where>标签来简化开发。修改 UserDao.xml 映射文件如下： 

![1533787276742](img/1533787276742.png)

+ <where />可以自动处理第一个 and 

### 3.动态标签之<foreach>标签 

#### 3.1需求一

+ 传入多个 id 查询用户信息，用下边sql 实现：

```
select uid ,username ,birthday ,sex, address from t_user WHERE username LIKE '张%' AND (uid =10 OR uid =89 OR uid=16)
```

这样我们在进行范围查询时，就要将一个集合中的值，作为参数动态添加进来。这样我们将如何进行参数的传递？ 

+ 在QueryVo.java 添加一个集合

```java
public class QueryVo {
    private User user;
    private List<Integer> ids;
	...
}
```

+ UserDao.java

```java
public interface UserDao {

    /**
     * 区间查询
     * @param queryVo
     * @return
     */
    List<User> findRange(QueryVo queryVo);
}
```

+ UserDao.xml

![1533788179358](img/1533788179358.png)



+ 测试

```java
    @Test
    public void fun02() throws Exception {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        QueryVo queryVo = new QueryVo();
        List<Integer> ids = new ArrayList<Integer>();
        ids.add(1);
        ids.add(5);
        ids.add(9);
        queryVo.setIds(ids);

        List<User> list = userDao.findRange(queryVo);


        System.out.println(list);

        sqlSession.close();
    }
```

#### 3.2需求二

+ 传入多个 id 查询用户信息，用下边sql 实现：

```
select uid ,username ,birthday ,sex, address from t_user WHERE username LIKE '张%' AND  uid IN (1,7,10,18)
```

+ UserDao.java

```java
public interface UserDao {
    /**
     * 区间查询
     * @param queryVo
     * @return
     */
    List<User> findRange02(QueryVo queryVo);
}
```

+ UserDao.xml

![1533788371459](img/1533788371459.png)

+ 测试

```java
    @Test
    public void fun03() throws Exception {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        QueryVo queryVo = new QueryVo();
        List<Integer> ids = new ArrayList<Integer>();
        ids.add(1);
        ids.add(5);
        ids.add(9);
        queryVo.setIds(ids);

        List<User> list = userDao.findRange02(queryVo);


        System.out.println(list);

        sqlSession.close();
    }

```

#### 3.3总结

foreach标签用于遍历集合，它的属性：

+ collection:代表要遍历的集合元素，注意编写时不要写#{}
+ open:代表语句的开始部分
+ close:代表语句结束部分
+ item:代表遍历集合的每个元素，生成的变量名
+ sperator:代表分隔符 

### 4.Mybatis 中简化编写的 SQL 片段 

​	Sql 中可将重复的 sql 提取出来，使用时用 include 引用即可，最终达到 sql 重用的目的。我们先到 UserDao.xml 文件中使用<sql>标签，定义出公共部分，如下： 

+ 使用sql标签抽取

```xml
<sql id="selectUserId">
  	select uid ,username ,birthday ,sex, address   from t_user
</sql>
```

+ 使用include标签引入使用

```xml
    <select id="findRange02" parameterType="queryVo" resultType="user">
        <include refid="selectUserId"></include>
        <where>
            <if test="user != null and user.username != null and user.username !=''">
                AND  username like #{user.username}
            </if>
            <if test="ids != null">
                <foreach collection="ids" item="id" open="uid IN (" close=")" separator="," >
                    #{id}
                </foreach>
            </if>
        </where>
    </select>
```

+ 整个图示

![1533788565405](img/1533788565405.png)

## 三,Mybatis 的多表关联查询 

### 1.一对一

#### 1.1 需求

​	本次案例以简单的用户和账户的模型来分析 Mybatis 多表关系。用户为 User 表，账户为Account 表。一个用户（User）可以有多个账户（Account）,但是一个账户(Account)只能属于一个用户(User)。具体关系如下： 

![img](img/tu_19.png)

​	查询所有账户信息， 关联查询账户的用户名和地址。因为一个账户信息只能供某个用户使用，所以从查询账户信息出发关联查询用户信息为一对一查询。

+ 数据库的准备

```java
CREATE TABLE t_account(
		aid INT PRIMARY KEY auto_increment,
		money DOUBLE,
		uid INT
);
ALTER TABLE t_account ADD FOREIGN KEY(uid) REFERENCES t_user(uid)
```

+ 查询语句

```sql
 SELECT a.*,u.username,u.address FROM t_account a,t_user u WHERE a.uid = u.uid
```

#### 1.2方式一

+ Account.java

```java
public class Account {
	private Integer aid;
	private Integer uid;
	private Double money;
}
```

+ AccountCustom.java

  ​	为了能够封装上面 SQL 语句的查询结果，定义 AccountCustom类中要包含账户信息同时还要包含用户信息，所以我们要在定义 AccountCustom类时可以继承 Account类 

```java
public class AccountCustom extends  Account {
    private String username;
    private String address;
	//get/set
}
```

+ AccountDao.java

```java
public interface AccountDao {
    /**
     * 查询账户信息(包含用户信息)
     * @return
     */
    List<AccountCustom> findAccountList();

}
```

+ AccountDao.xml

```xml
<mapper namespace="com.itheima.dao.AccountDao">
    <select id="findAccountList" resultType="AccountCustom">
        SELECT a.*,u.username,u.address FROM t_account a,t_user u WHERE a.uid = u.uid
    </select>
</mapper>
```

#### 1.3方式二

+ 修改Account.java

  在 Account 类中加入 User类的对象作为 Account 类的一个属性。 

![img](img/tu_20.png)

+ AccountDao.java

```java
public interface AccountDao {
    /**
     * 查询账户信息(包含用户信息)
     * @return
     */
    List<Account02> findAccountList02();

}
```

+ AccountDao.xml

```xml
    <select id="findAccountList02" resultMap="accountListMap">
        SELECT a.*,u.username,u.address FROM t_account a, t_user u WHERE a.uid = u.uid
    </select>
    
    <resultMap id="accountListMap" type="Account02">
        <id column="aid" property="aid"></id>
        <result column="money" property="money"></result>
        <result column="uid" property="uid"></result>
        <!--association用于关联加载的对象,property为需要加载对象,javaType为需要加载对应的类型-->
        <association property="user" javaType="User">
            <result column="username" property="username"></result>
            <result column="address" property="address"></result>
        </association>
    </resultMap>
```

### 2.一对多

#### 2.1需求

​	需求： 查询所有用户信息及用户关联的账户信息。
​	分析： 用户信息和他的账户信息为一对多关系，并且查询过程中如果用户没有账户信息，此时也要将用户信息查询出来，我们想到了左外连接查询比较合适。 

+ sql语句

```mysql
SELECT u.*, a.aid, a.money  FROM t_user u LEFT OUTER JOIN t_account a ON u.uid = a.uid
```

#### 2.2实现

+ Account.java

```java
public class Account {
    private Integer aid;
    private Integer uid;
    private Double money;
}
```

+ User.java

  ​	为了能够让查询的 User 信息中，带有他的个人多个账户信息，我们就需要在 User 类中添加一个集合，
  用于存放他的多个账户信息，这样他们之间的关联关系就保存了。 

```java
public class User implements Serializable{
    private int uid;
    private String username;// 用户姓名
    private String sex;// 性别
    private Date birthday;// 生日
    private String address;// 地址

    //表达关系:1个用户对应多个账户
    private List<Account> accounts;
}
```

+ UserDao.java

```java
public interface UserDao {
    /**
     * 查询所有的用户对应的账户信息
     * @return
     */
    List<User> findUserAccountList();

}
```

+ UserDao.xml

```xml
<mapper namespace="com.itheima.dao.UserDao">
    <select id="findUserAccountList" resultMap="userAccountListMap">
        SELECT u.*, a.aid, a.money  FROM t_user u LEFT OUTER JOIN t_account a ON u.uid = a.uid
    </select>
    <resultMap id="userAccountListMap" type="user">
        <id property="uid" column="uid"></id>
        <result property="username" column="username"></result>
        <result property="sex" column="sex"></result>
        <result property="birthday" column="birthday"></result>
        <result property="address" column="address"></result>
        <!--加载多方数据,property属性:一方类里面List集合的属性名; ofType:List中的对象类型-->
        <collection property="accounts" ofType="account">
            <result property="aid" column="aid"></result>
            <result property="money" column="money"></result>
        </collection>
    </resultMap>
</mapper>
```

### 3.多对多

#### 3.1 需求

​	通过前面的学习，我们使用 Mybatis 实现一对多关系的维护。多对多关系其实我们看成是双向的一对多关系。用户与角色的关系模型就是典型的多对多关系.

![img](img/tu_21.png)

+ 建表语句

```sql
CREATE TABLE t_role(
	rid INT PRIMARY KEY AUTO_INCREMENT,
	rName varchar(40),
	rDesc varchar(40)
);
CREATE TABLE user_role(
	uid INT,
	rid INT
);

ALTER TABLE  user_role ADD FOREIGN KEY(uid) REFERENCES t_user(uid);
ALTER TABLE  user_role ADD FOREIGN KEY(rid) REFERENCES t_role(rid);
```

需求：实现查询所有角色对象并且加载它所分配的用户信息。 

分析：查询角色我们需要用到 Role 表，但角色分配的用户的信息我们并不能直接找到用户信息，而是要通过中间表(USER_ROLE 表)才能关联到用户信息。
下面是实现的 SQL 语句： 

```sql
SELECT r.*, u.uid, u.username,u.sex,u.birthday,u.address FROM t_role r INNER JOIN user_role ur
ON r.rid = ur.rid INNER JOIN t_user u ON ur.uid = u.uid
或者
SELECT r.*, u.uid, u.username,u.sex,u.birthday,u.address FROM  t_role r, user_role ur, t_user u
WHERE r.rid = ur.rid AND ur.uid = u.uid
```

#### 3.2实现

+ User.java

```java
public class User implements Serializable{
    private int uid;
    private String username;// 用户姓名
    private String sex;// 性别
    private Date birthday;// 生日
    private String address;// 地址
}
```

+ Role.java

```java
public class Role {
    private Integer rid;
    private String rName;
    private String rDesc;

    //1个角色对应多个用户
    private List<User> users;
	
}
```

+ RoleDao.java

```java
public interface RoleDao {
    /**
     * 查询角色信息
     * @return
     */
    List<Role> findRoleList();
}
```

+ RoleDao.xml

```xml
<mapper namespace="com.itheima.dao.RoleDao">
    <select id="findRoleList" resultMap="roleListMap">
        SELECT r.*,u.username,u.sex,u.birthday, u.address FROM t_role r,user_role ur,t_user u WHERE r.rid = ur.rid AND ur.uid = u.uid
    </select>

    <resultMap id="roleListMap" type="role">
        <id column="rid" property="rid"></id>
        <result column="rName" property="rName"></result>
        <result column="rDesc" property="rDesc"></result>
        <collection property="users" ofType="user">
            <result property="username" column="username"></result>
            <result property="sex" column="sex"></result>
            <result property="birthday" column="birthday"></result>
            <result property="address" column="address"></result>
        </collection>

    </resultMap>
</mapper>
```