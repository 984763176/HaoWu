
# spring5第四天
## 学习目标

+ 能够使用spring的jdbc的模板
+ 能够配置spring的连接池
+ 能够使用jdbc模板完成增删改查的操作
+ 能够应用编程式事务
+ 能够理解事务的传播行为
+ 能够说出两种编写Dao代码的区别

## 一,Spring中的JdbcTemplate 

### 1.JDBC模版入门

#### 1.1.概述 

​	Spring除了IOC 和 AOP之外，还对Dao层的提供了支持。 就算没有框架，也对原生的JDBC提供了支持。它是spring框架中提供的一个对象，是对原始Jdbc API对象的简单封装。spring框架为我们提供了很多的操作模板类。

|   持久化技术   |                   模版类                    |
| :-------: | :--------------------------------------: |
|   JDBC    | org.springframework.jdbc.core.JdbcTemplate |
| Hibrenate | org.springframework.orm.hibernate5.HibernateTemplate |
|  MyBatis  |  org.mybatis.spring.SqlSessionTemplate   |

#### 1.2JDBC模版入门案例

+ 创建Maven工程,导入坐标

```xml
  <dependencies>
    <!--Spring核心容器-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-context</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--SpringJdbc-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-jdbc</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--事务相关的-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-tx</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>5.1.6</version>
    </dependency>
    <!--Spring整合单元测试-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-test</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--单元测试-->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.12</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
```

+ 表结构创建和JavaBean


```mysql
create table account(
    id int primary key auto_increment,
    name varchar(40),
    money double
)character set utf8 collate utf8_general_ci;

insert into account(name,money) values('zs',1000);
insert into account(name,money) values('ls',1000);
insert into account(name,money) values('ww',1000);
```

+ 实体

```java
public class Account implements Serializable{
    private Integer id;
    private String name;
    private Double money;
  ...
}
```

+ 使用JDBC模版API

```java
	//使用JDBC模版保存
	public void save(Account account) {
		//1. 创建数据源
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/spring_day03");
		dataSource.setUsername("root");
		dataSource.setPassword("123456");
		
		//2. 创建JDBC模版
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(dataSource);
		
		//3.操作数据库
		String sql = "insert into account values(?,?,?)";
		jdbcTemplate.update(sql, null,account.getName(),account.getMoney())
		
	}	
```

### 2.使用JDBC模版完成CRUD

1. 增加

   ```java
   String sql = "insert into account values(?,?,?)";
   jdbcTemplate.update(sql, null,account.getName(),account.getMoney());
   ```

2. 修改

   ```java
   String sql ="update account set name = ? where id = ?";
   Object[] objects = {user.getName(), user.getId()};
   jdbcTemplate.update(sql,objects);
   ```

3. 删除

   ```java
   String sql = "delete from account where id=?";
   jdbcTemplate.update(sql, 6);
   ```

4. 查询单个值

   ```java
   String sql = "select count(*) from t_user";
   Long n = jdbcTemplate.queryForObject(sql, Long.class);
   ```

   ```java
   String sql = "select name from t_user where id=?";
   String name = jdbcTemplate.queryForObject(sql, String.class, 4);
   System.out.println(name);
   ```

5. 查询单个对象

   ```java
   String sql = "select * from account where id = ?";
   User user = jdbcTemplate.queryForObject(sql,new BeanPropertyRowMapper<>(Account.class),id);
   ```

6. 查询集合

   ```
   String sql = "select * from account";
   List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
   System.out.println(list);
   ```

   ```java
   String sql = "select * from account";
   List<Account> list = List<User> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class));
   ```

### 3.在dao中使用JdbcTemplate

#### 3.1方式一

​	这种方式我们采取在dao中定义JdbcTemplate

+ AccountDaoImpl.java


```java
public class AccountDaoImpl implements AccountDao {

	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public Account findAccountById(Integer id) {
		List<Account> list =  jdbcTemplate.query("select * from account where id = ? ",new AccountRowMapper(),id);
		return list.isEmpty()?null:list.get(0);
	}

	@Override
	public Account findAccountByName(String name) {
		List<Account> list =  jdbcTemplate.query("select * from account where name = ? ",new AccountRowMapper(),name);
		if(list.isEmpty()){
			return null;
		}
		if(list.size()>1){
			throw new RuntimeException("结果集不唯一，不是只有一个账户对象");
		}
		return list.get(0);
	}

	@Override
	public void updateAccount(Account account) {
		jdbcTemplate.update("update account set money = ? where id = ? ",account.getMoney(),account.getId());
	}

}
```

+ applicationContext.xml

```xml
	<!-- 配置一个dao -->
	<bean id="accountDao" class="com.itheima.dao.impl.AccountDaoImpl">
		<!-- 注入jdbcTemplate -->
		<property name="jdbcTemplate" ref="jdbcTemplate"></property>
	</bean>
	
	<!-- 配置一个数据库的操作模板：JdbcTemplate -->
	<bean id="jdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate">
		<property name="dataSource" ref="dataSource"></property>
	</bean>
	
	<!-- 配置数据源 -->
	<bean id="dataSource" class="org.springframework.jdbc.datasource.DriverManagerDataSource">
		<property name="driverClassName" value="com.mysql.jdbc.Driver"></property>
		<property name="url" value="jdbc:mysql:///spring_day04"></property>
		<property name="username" value="root"></property>
		<property name="password" value="123456"></property>
	</bean>
```

#### 3.2方式二

​	这种方式我们采取让dao继承JdbcDaoSupport

+ AccountDaoImpl.java

```java
public class AccountDaoImpl extends JdbcDaoSupport implements AccountDao {

	@Override
	public Account findAccountById(Integer id) {
		//getJdbcTemplate()方法是从父类上继承下来的。
		List<Account> list = getJdbcTemplate().query("select * from account where id = ? ",new AccountRowMapper(),id);
		return list.isEmpty()?null:list.get(0);
	}

	@Override
	public Account findAccountByName(String name) {
		//getJdbcTemplate()方法是从父类上继承下来的。
		List<Account> list =  getJdbcTemplate().query("select * from account where name = ? ",new AccountRowMapper(),name);
		if(list.isEmpty()){
			return null;
		}
		if(list.size()>1){
			throw new RuntimeException("结果集不唯一，不是只有一个账户对象");
		}
		return list.get(0);
	}

	@Override
	public void updateAccount(Account account) {
		//getJdbcTemplate()方法是从父类上继承下来的。
		getJdbcTemplate().update("update account set money = ? where id = ? ",account.getMoney(),account.getId());
	}
}
```

+ applicationContext.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
    	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    	xsi:schemaLocation="http://www.springframework.org/schema/beans 
    	http://www.springframework.org/schema/beans/spring-beans.xsd">
	
<!-- 配置dao2 -->
<bean id="accountDao" class="com.itheima.dao.impl.AccountDaoImpl">
	<!-- 注入dataSource -->
	<property name="dataSource" ref="dataSource"></property>
</bean>
<!-- 配置数据源 -->
<bean id="dataSource" class="org.springframework.jdbc.datasource.DriverManagerDataSource">
	<property name="driverClassName" value="com.mysql.jdbc.Driver"></property>
	<property name="url" value="jdbc:mysql:///spring_day04"></property>
		<property name="username" value="root"></property>
		<property name="password" value="123456"></property>
	</bean>
</beans>
```

#### 3.3两种方式比较

​	第一种在Dao类中定义JdbcTemplate的方式，适用于所有配置方式（xml和注解都可以）。

​	第二种让Dao继承JdbcDaoSupport的方式，只能用于基于XML的方式，注解用不了.



## 二,Spring配置第三方连接池

### 1.Spring配置C3P0连接池

​	官网:http://www.mchange.com/projects/c3p0/	

+ 导入坐标


```xml
  <dependency>
    	<groupId>c3p0</groupId>
    	<artifactId>c3p0</artifactId>
    	<version>0.9.1.2</version>
  </dependency>
```

+ 配置数据源连接池

  ```xml
   <!-- 配置C3P0数据库连接池 -->
   <bean id="dataSource" class="com.mchange.v2.c3p0.ComboPooledDataSource">
  	<property name="jdbcUrl" value="jdbc:mysql:///spring_jdbc" />
  	<property name="driverClass" value="com.mysql.jdbc.Driver" />
  	<property name="user" value="root" />
  	<property name="password" value="123456" />
   </bean>
   <!-- 管理JDBC模版 -->
   <bean id="jdbcTemplete" class="org.springframework.jdbc.core.JdbcTemplate">
  	<property name="dataSource" ref="dataSource" />
   </bean>
  ```

  > 核心类：`com.mchange.v2.c3p0.ComboPooledDataSource`

### 2.Spring配置Druid连接池

​	官网:http://druid.io/

- 导入坐标

  ```xml
  <dependency>
      <groupId>com.alibaba</groupId>
      <artifactId>druid</artifactId>
      <version>1.0.9</version>
  </dependency>
  ```

- 配置数据源连接池


```xml
    <!--注册dataSource -->
    <bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource">
        <property name="driverClassName" value="com.mysql.jdbc.Driver"></property>
        <property name="url" value="jdbc:mysql://localhost:3306/spring_day03"></property>
        <property name="username" value="root"></property>
        <property name="password" value="123456"></property>
    </bean>

    <bean id="jdbcTemplate" class="org.springframework.jdbc.core.JdbcTemplate">
        <constructor-arg name="dataSource" ref="dataSource"></constructor-arg>
    </bean>
```


### 3.Spring配置DBCP连接池【扩展】

​	官网:http://commons.apache.org/proper/commons-dbcp/download_dbcp.cgi

+ 导入坐标

  ```xml
  <dependency>
    	<groupId>commons-dbcp</groupId>
    	<artifactId>commons-dbcp</artifactId>
    	<version>1.4</version>
  </dependency>
  ```

+ 配置连接池

  ```xml
   <!-- 配置DBCP数据库连接池 -->
  <bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource">
  <property name="url" value="jdbc:mysql:///spring_jdbc" />
  <property name="driverClassName" value="com.mysql.jdbc.Driver" />
  <property name="username" value="root" />
  <property name="password" value="123456" />
  </bean>
   <!-- 管理JDBC模版 -->
  <bean id="jdbcTemplete" class="org.springframework.jdbc.core.JdbcTemplate">
  <property name="dataSource" ref="dataSource" />
  </bean>
  ```

  >  核心类：`org.apache.commons.dbcp.BasicDataSource`


### 4.Spring配置HikariCP连接池【扩展】	

​	官网:https://github.com/brettwooldridge/HikariCP

+ 导入HikariCP坐标

  ```xml
  <dependency>
     <groupId>com.zaxxer</groupId>
     <artifactId>HikariCP</artifactId>
     <version>3.1.0</version>
  </dependency>
  ```

+ 配置数据源连接池

  ```xml
   <!-- 配置HikariCP数据库连接池 -->
  <bean id="dataSource" class="com.zaxxer.hikari.HikariDataSource">
  	<property name="jdbcUrl" value="jdbc:mysql:///spring_jdbc" />
  	<property name="driverClassName" value="com.mysql.jdbc.Driver" />
  	<property name="username" value="root" />
  	<property name="password" value="123456" />
  </bean>
   <!-- 管理JDBC模版 -->
  <bean id="jdbcTemplete" class="org.springframework.jdbc.core.JdbcTemplate">
  <property name="dataSource" ref="dataSource" />
  </bean>
  ```

  >  核心类：`com.zaxxer.hikari.HikariDataSource`

### 5.Spring引入Properties配置文件

+ 步骤

  1.定义jdbc.properties文件

  2.在spring核心配置文件里面引入配置文件

  3.根据key获得值

#### 5.1 定义配置文件

+ jdbc.properties

```properties
jdbc.driver=com.mysql.jdbc.Driver
jdbc.url=jdbc:mysql://localhost:3306/spring_day03
jdbc.username=root
jdbc.password=123456
```

#### 5.2在applicationContext.xml页面使用

* 引入配置文件方式一(不推荐使用)

```xml
 <!-- 引入properties配置文件：方式一 (繁琐不推荐使用) -->
<bean id="properties" class="org.springframework.beans.factory.config.PropertyPlaceholderConfigurer"> 
	<property name="location" value="classpath:jdbc.properties" />
</bean>
```

* 引入配置文件方式二

```xml
 <!-- 引入properties配置文件：方式二 (简单推荐使用) -->
<context:property-placeholder location="classpath:jdbc.properties" />
```

* bean标签中引用配置文件内容
```xml
 <!-- hikariCP 连接池 -->
<bean id="dataSource" class="com.zaxxer.hikari.HikariDataSource">
	<property name="jdbcUrl" value="${jdbc.url}" />
	<property name="driverClassName" value="${jdbc.driver}" />
	<property name="username" value="${jdbc.username}" />
	<property name="password" value="${jdbc.password}" />
</bean>
```

> 注意:在使用`<context:property-placeholder/>`标签时，properties配置文件中的key一定要是带点分隔的。例如`jdbc.url`
>



## 三,Spring管理事务   

### 1.概述和事务相关的API

#### 1.1概述

​	由于Spring对持久层的很多框架都有支持 ， Hibernate 、 jdbc 、 MyBatis 由于使用的框架不同，所以使用事务管理操作API 也不尽相同。 为了规范这些操作， Spring统一定义一个事务的规范 ，这其实是一个接口 。这个接口的名称 ： PlatformTrasactionManager.并且它对已经做好的框架都有支持.

​	如果dao层使用的是JDBC 或者mybatis,那么 可以使用DataSourceTransactionManager 来处理事务

​	如果dao层使用的是 Hibernate, 那么可以使用HibernateTransactionManager 来处理事务

#### 1.2相关的API

##### 1.2.1PlatformTransactionManager 

​	平台事务管理器是一个接口，实现类就是Spring真正管理事务的对象。

​	常用的实现类:

​		DataSourceTransactionManager    :JDBC开发的时候，使用事务管理。

​		HibernateTransactionManager       :Hibernate开发的时候，使用事务管理。

##### 1.2.2TransactionDefinition 

​	事务定义信息中定义了事务的隔离级别，传播行为，超时信息，只读。

##### 1.2.3 TransactionStatus:事务的状态信息

​	事务状态信息中定义事务是否是新事务，是否有保存点。

### 2.编程式事务【了解】  

+ 添加依赖

```xml
  <dependencies>
    <!--Spring核心容器-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-context</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--SpringJdbc-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-jdbc</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--事务相关的-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-tx</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--SpringAOP相关的坐标-->
    <dependency>
      <groupId>org.aspectj</groupId>
      <artifactId>aspectjweaver</artifactId>
      <version>1.8.7</version>
    </dependency>
  <!--数据库驱动-->
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>5.1.6</version>
    </dependency>
    <!--Spring整合单元测试-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-test</artifactId>
      <version>5.0.2.RELEASE</version>
    </dependency>
    <!--单元测试-->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.12</version>
      <scope>test</scope>
    </dependency>
	 <!--连接池-->
    <dependency>
      <groupId>com.zaxxer</groupId>
      <artifactId>HikariCP</artifactId>
      <version>3.1.0</version>
    </dependency>
  </dependencies>
```

+ 代码

```java
public class JDBCTempleTest {
	 @Test
	 public void fun01() throws PropertyVetoException{
			//1. 创建数据源
      HikariDataSource dataSource = new HikariDataSource();
			 dataSource.setDriverClass("com.mysql.jdbc.Driver");
			 dataSource.setJdbcUrl("jdbc:mysql://localhost:3306/spring_day03");
			 dataSource.setUser("root");
			 dataSource.setPassword("123456");
			 //2. 创建jdbc模版
			 final JdbcTemplate jdbcTemplate = new JdbcTemplate();
			 jdbcTemplate.setDataSource(dataSource);
			 //3.创建事务管理者
			 DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
			 transactionManager.setDataSource(dataSource);
			 //4.创建事务模版
			 TransactionTemplate transactionTemplate = new TransactionTemplate();
			 transactionTemplate.setTransactionManager(transactionManager);
			 	//. 进行事务操作
			 transactionTemplate.execute(new TransactionCallback<Object>() {
                @Override
                public Object doInTransaction(TransactionStatus status) {
                    //操作数据库
                    jdbcTemplate.update("update t_account set money = money - ? where name = ?  ", 	100.0,"zs");

                    int i = 1/0;

                    jdbcTemplate.update("update t_account set money = money + ? where name = ?  ", 100.0,"ls");
                    return null;
                }
            });
         }
}
```

### 3.Spring声明式事务-xml配置方式【重点】

​	声明式的事务管理的思想就是AOP的思想。面向切面的方式完成事务的管理。声明式事务有两种,==xml配置方式和注解方式.==

#### 3.1 配置步骤

+ 配置事务管理器

  ```xml
  <bean id="transactionManager" 		class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
  		<property name="dataSource" ref="dataSource"></property>
  </bean>
  ```

+ 配置事务建议(事务的规则)

  ```xml
  <!--在tx:advice标签内部 配置事务的属性 -->
  <tx:attributes>
  <!-- 指定方法名称：是业务核心方法 
  	read-only：是否是只读事务。默认false，不只读。
  	isolation：指定事务的隔离级别。默认值是使用数据库的默认隔离级别。 
  	propagation：指定事务的传播行为。
  	timeout：指定超时时间。默认值为：-1。永不超时。
  	rollback-for：用于指定一个异常，当执行产生该异常时，事务回滚。产生其他异常，事务不回滚。没有默认值，任何异常都回滚。
  	no-rollback-for：用于指定一个异常，当产生该异常时，事务不回滚，产生其他异常时，事务回滚。没有默认值，任何异常都回滚。
  	-->
  	<tx:method name="*" read-only="false" propagation="REQUIRED"/>
  	<tx:method name="find*" read-only="true" propagation="SUPPORTS"/>
  </tx:attributes>
  ```

+ 配置事务的AOP

  ```xml
  <aop:config>
  	<!-- 定义切入点 ，也就是到底给那些类中的那些方法加入事务的管理 -->
  	<aop:pointcut expression="execution(* com.itheima.service.impl.*.*(..))" id="pointCat"/>
  	<!-- 让切入点和事务的建议绑定到一起 -->
  	<aop:advisor advice-ref="txAdvice" pointcut-ref="pointCat"/>
  </aop:config>
  ```

  ​



#### 3.2事务的传播行为

##### 3.2.1事务的传播行为的作用

​	我们一般都是将事务设置在Service层,那么当我们调用Service层的一个方法的时候, 它能够保证我们的这个方法中,执行的所有的对数据库的更新操作保持在一个事务中， 在事务层里面调用的这些方法要么全部成功，要么全部失败。

​	如果你的Service层的这个方法中，除了调用了Dao层的方法之外， 还调用了本类的其他的Service方法，那么在调用其他的Service方法的时候， 我必须保证两个service处在同一个事务中，确保事物的一致性。

​	 事务的传播特性就是解决这个问题的。

##### 3.2.2 事务的传播行为的取值

保证在同一个事务里面:

- **PROPAGATION_REQUIRED:默认值，也是最常用的场景.**

  如果当前没有事务，就新建一个事务，
  如果已经存在一个事务中，加入到这个事务中。

- PROPAGATION_SUPPORTS：

  如果当前没有事务，就以非事务方式执行。

  如果已经存在一个事务中，加入到这个事务中。

- PROPAGATION_MANDATORY

  如果当前没有有事务，就抛出异常; 

  如果已经存在一个事务中，加入到这个事务中。

保证不在同一个事物里:

- **PROPAGATION_REQUIRES_NEW**

  如果当前有事务，把当前事务挂起,创建新的事务但独自执行

- PROPAGATION_NOT_SUPPORTED

  如果当前存在事务，就把当前事务挂起。不创建事务

- PROPAGATION_NEVER

  如果当前存在事务，抛出异常

### 4.spring声明式事务-注解方式【重点】 

+ 在applicationContext里面打开注解驱动

  ```xml
  <!--一,配置事务管理器  -->
  	<bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
  		<property name="dataSource" ref="dataSource"></property>
  	</bean>
  	
  <!--二配置事务注解  -->
  <tx:annotation-driven transaction-manager="transactionManager"/>
  ```

+ 在业务逻辑类上面使用注解

  @Transactional ： 如果在类上声明，那么标记着该类中的所有方法都使用事务管理。也可以作用于方法上，那么这就表示只有具体的方法才会使用事务。




## 四,Spring5 的新特性【了解】 

### 1.与 JDK 相关的升级 

#### 1.1jdk 版本要求

​	spring5.0 在 2017 年 9 月发布了它的 GA（通用）版本。该版本是基于 jdk8 编写的， 所以 jdk8 以下版本
将无法使用。 同时，可以兼容 jdk9 版本。tomcat 版本要求 8.5 及以上。
注：
​	我们使用 jdk8 构建工程，可以降版编译。但是不能使用 jdk8 以下版本构建工程。

#### 1.2利用 jdk8 版本更新的内容 

+ 基于 JDK8 的反射增强 

```java
public class Test {
    //循环次数定义： 10 亿次
    private static final int loopCnt = 1000 * 1000 * 1000;
    public static void main(String[] args) throws Exception {
        //输出 jdk 的版本
        System.out.println("java.version=" + System.getProperty("java.version"));
        t1();
        t2();
        t3();
    }
    // 每次重新生成对象
    public static void t1() {
        long s = System.currentTimeMillis();
        for (int i = 0; i < loopCnt; i++) {
            Person p = new Person();
            p.setAge(31);
        }
        long e = System.currentTimeMillis();
        System.out.println("循环 10 亿次创建对象的时间： " + (e - s));
    }
    // 同一个对象
    public static void t2() {
        long s = System.currentTimeMillis();
        Person p = new Person();
        for (int i = 0; i < loopCnt; i++) {
            p.setAge(32);
        }
        long e = System.currentTimeMillis();
        System.out.println("循环 10 亿次给同一对象赋值的时间： " + (e - s));
    }
    //使用反射创建对象
    public static void t3() throws Exception {
        long s = System.currentTimeMillis();
        Class<Person> c = Person.class;
        Person p = c.newInstance();
        Method m = c.getMethod("setAge", Integer.class);
        for (int i = 0; i < loopCnt; i++) {
            m.invoke(p, 33);
        }
        long e = System.currentTimeMillis();
        System.out.println("循环 10 亿次反射创建对象的时间： " + (e - s));
    }
    static class Person {
        private int age = 20;
        public int getAge() {
            return age;
        }
        public void setAge(Integer age) {
            this.age = age;
        }
    }
}
```

![img](img/tu_1.png)

+ @NonNull 注解和@Nullable 注解的使用 

  ​	用 @Nullable 和 @NotNull 注解来显示表明可为空的参数和以及返回值。这样就够在编译的时候处理空值而不是在运行时抛出 NullPointerExceptions。 

+ 日志记录方面 

  ​	Spring Framework 5.0 带来了 Commons Logging 桥接模块的封装, 它被叫做 spring-jcl 而不是标准的 Commons Logging。当然，无需任何额外的桥接，新版本也会对 Log4j 2.x, SLF4J, JUL( java.util.logging) 进行自动检测。 

### 2.核心容器的更新 

​	Spring Framework 5.0 现在支持候选组件索引作为类路径扫描的替代方案。该功能已经在类路径扫描器中添加，以简化添加候选组件标识的步骤。应用程序构建任务可以定义当前项目自己的 META-INF/spring.components 文件。在编译时，源模型是自包含的， JPA 实体和 Spring 组件是已被标记的。从索引读取实体而不是扫描类路径对于小于 200 个类的小型项目是没有明显差异。但对大型项目影响较大。加载组件索引开销更低。因此，随着类数的增加，索引读取的启动时间将保持不变。	加载组件索引的耗费是廉价的。因此当类的数量不断增长，加上构建索引的启动时间仍然可以维持一个常数,不过对于组件扫描而言，启动时间则会有明显的增长。	这个对于我们处于大型 Spring 项目的开发者所意味着的，是应用程序的启动时间将被大大缩减。虽然 20	或者 30 秒钟看似没什么，但如果每天要这样登上好几百次，加起来就够你受的了。使用了组件索引的话，就能帮助你每天过的更加高效。

​	你可以在 Spring 的 Jira 上了解更多关于组件索引的相关信息。 

### 3.JetBrains Kotlin 语言支持 

​	Kolin概述：是一种支持函数式编程编程风格的面向对象语言。 Kotlin 运行在 JVM 之上，但运行环境并不
限于 JVM。    

+ Kolin 的示例代码：

```java
{

  ("/movie" and accept(TEXT_HTML)).nest {

  GET("/", movieHandler::findAllView)

  GET("/{card}", movieHandler::findOneView)

  }

  ("/api/movie" and accept(APPLICATION_JSON)).nest {

  GET("/", movieApiHandler::findAll)

  GET("/{id}", movieApiHandler::findOne)

  }

}
```

+ Kolin 注册 bean 对象到 spring 容器：

```java
val context = GenericApplicationContext {
  registerBean()
  registerBean { Cinema(it.getBean()) }
}
```

### 4.响应式编程风格 

​	此次 Spring 发行版本的一个激动人心的特性就是新的响应式堆栈 WEB 框架。这个堆栈完全的响应式且非阻塞，适合于事件循环风格的处理，可以进行少量线程的扩展。
​	Reactive Streams 是来自于 Netflix, Pivotal, Typesafe, Red Hat, Oracle, Twitter 以及Spray.io 的工程师特地开发的一个 API。它为响应式编程实现 的实现提供一个公共 的 API，好实现Hibernate 的 JPA。这里 JPA 就是这个 API, 而 Hibernate 就是实现。Reactive Streams API 是 Java 9 的官方版本的一部分。在 Java 8 中, 你会需要专门引入依赖来使用 Reactive Streams API。Spring Framework 5.0 对于流式处理的支持依赖于 Project Reactor 来构建, 其专门实现了Reactive Streams API。
​	Spring Framework 5.0 拥有一个新的 spring-webflux 模块，支持响应式 HTTP 和 WebSocket 客
户端 Spring Framework 5.0 还提供了对于运行于服务器之上，包含了 REST, HTML, 以及 WebSocket 风格交互的响应式网页应用程序的支持。在 spring-webflux 中包含了两种独立的服务端编程模型：基于注解：使用到了@Controller 以及 Spring MVC 的其它一些注解；使用 Java 8 lambda 表达式的函数式风格的路由和处理。有 了 Spring Webflux, 你 现 在 可 以 创 建 出 WebClient, 它 是 响 应 式 且 非 阻 塞 的 ， 可 以 作 为RestTemplate 的一个替代方案。 

+ 这里有一个使用 Spring 5.0 的 REST 端点的 WebClient 实现：

```java
WebClient webClient = WebClient.create();
Movie movie = webClient.get().uri("http://localhost:8080/movie/42").accept(MediaType.APPLICATION_JSON)
.exchange().then(response -> response.bodyToMono(Movie.class)); 
```

### 5.Junit5 支持 

​	完全支持 JUnit 5 Jupiter，所以可以使用 JUnit 5 来编写测试以及扩展。此外还提供了一个编程以及扩展模型， Jupiter 子项目提供了一个测试引擎来在 Spring 上运行基于 Jupiter 的测试。
​	另外， Spring Framework 5 还提供了在 Spring TestContext Framework 中进行并行测试的扩展。针对响应式编程模型， spring-test 现在还引入了支持 Spring WebFlux 的 WebTestClient 集成测试的支持，类似于 MockMvc，并不需要一个运行着的服务端。使用一个模拟的请求或者响应， WebTestClient就可以直接绑定到 WebFlux 服务端设施。
​	你可以在这里找到这个激动人心的 TestContext 框架所带来的增强功能的完整列表。当然， Spring Framework 5.0 仍然支持我们的老朋友 JUnit! 在我写这篇文章的时候， JUnit 5 还只是发展到了 GA 版本。对于 JUnit4， Spring Framework 在未来还是要支持一段时间的。

### 6.依赖类库的更新 

+ 终止支持的类库 

  ​	Portlet.
  ​	Velocity.
  ​	JasperReports.
  ​	XMLBeans.
  ​	JDO.
  ​	Guava.

+ 支持的类库

  ​	Jackson 2.6+
  ​	EhCache 2.10+ / 3.0 GA
  ​	Hibernate 5.0+
  ​	JDBC 4.0+
  ​	XmlUnit 2.x+
  ​	OkHttp 3.x+
  ​	Netty 4.1+ 

  ​