---
typora-copy-images-to: img
---

# Listener  #

## 案例一:监听ServletContext的创建和销毁

### 一,案例需求

​	监听ServletContext域对象的创建和销毁. 

​	问题: ServletContext什么时候创建,什么时候销毁?

​		 服务器启动(项目部署的时候)创建

​		服务器正常关闭销毁

​		表面看监听ServletContext的创建和销毁, 换句话来说, 监听服务器启动和关闭的

### 二,技术分析

#### 1.Listener的概述

##### 1.1什么是Listener

​	监听器就是一个Java类,用来监听其他的JavaBean的变化 

​	在javaweb中监听器就是监听**三个域对象**的状态的。request,session,servletContext(application)

##### 1.2监听器的应用

​	主要在Swing编程  

​	在Android大量应用  

​	JS里面的事件

##### 1.3监听器的术语

​	eg: 一个狗仔拍明星出轨 

​	事件源 :被监听的对象.(目标对象)          	 			明星  				

    	监听器对象：监听的对象.              	  				狗仔 			

    	事件：事件源行为的称呼.         						出轨				

​	注册(绑定):将"监听器"对象注册给"事件源".     		       狗仔去明星的楼下蹲点			

​	事件对象:在"监听器对象"中获得"事件源"      			狗仔镜头里面可以捕获明星出轨的证据	

#### 2.ServletContextListener

##### 2.1概述

ServletContextListener是监听ServletContext对象的创建和销毁的

问题  :ServletContext对象何时创建和销毁:

    	创建：服务器启动时候(前提是这个项目在这个服务器里面).  服务器为每个WEB应用创建一个单独的ServletContext.

    	销毁：服务器关闭的时候,或者项目从服务器中移除.

##### 2.2ServletContextListener的使用

###### 2.2.1编写步骤

​	1.编写一个类,实现ServletContextListener接口

​	2.在web.xml里面注册注册listener

###### 2.2.2代码实现

- JAVA代码

  ```java
  public class ServletContextLis implements ServletContextListener {

  	
  	@Override
  	public void contextInitialized(ServletContextEvent sce) {
  		//相当于服务器启动:加载配置 Spring
  		System.out.println("ServletContext 创建了... 555555");

  	}

  	@Override
  	public void contextDestroyed(ServletContextEvent sce) {
  		System.out.println("ServletContext 销毁了... 444444");
  	}

  }
  ```

- 配置(web.xml)

  ```xml
    <listener>
    	<!-- 全限定名(带包名) -->
    	<listener-class>com.itheima.web.listener.ServletContextLis</listener-class>
    </listener>
  ```

##### 2.3ServletContextListener企业中应用

​	初始化工作.

​	加载配置文件:Spring框架,ContextLoaderListener



## 常见设计模式:

+ 单例模式
+ 装饰者
+ 代理(动态代理)
+ 工厂模式
+ 构建模式 
+ 责任链
+ 类模板模式(模板方法)
+ 观察者

