package com.itheima.context;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/context01", name="Demo01ContextServlet")
public class Demo01ContextServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取ServletContext对象
        ServletContext context = this.getServletContext();
        System.out.println("Demo01ContextServlet里边获取的：" + context);


        //向ServletContext里放一个数据
        //context.setAttribute("username", "zhangsan");
        //从ServletContext里取一个数据
        //Object username = context.getAttribute("username");
        //System.out.println("Demo01ContextServlet里边获取的username：" + username);
        //从ServletContext里删除一个数据
        //context.removeAttribute("username");
        //username = context.getAttribute("username");
        // System.out.println("Demo01ContextServlet里边删除后再获取的username：" + username);

        /**
         * ServletContext获取web应用里的资源
         * 资源路径：从web下开始查找的资源路径。  /d.txt  从web下找a.txt
         */
        String apath = context.getRealPath("/a.txt");
        System.out.println(apath);

        String bpath = context.getRealPath("/WEB-INF/b.txt");
        System.out.println(bpath);

        String cpath = context.getRealPath("/WEB-INF/classes/com/itheima/context/c.txt");
        System.out.println(cpath);

        String dpath = context.getRealPath("/WEB-INF/classes/d.txt");
        System.out.println(dpath);

        //int i = 1/0;

        response.getWriter().print("demo01servlet");

        //e.txt 获取不到。不在有效路径里

        /*try {
            InputStream is = context.getResourceAsStream("/a.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"));
            String s = reader.readLine();
            System.out.println(s);
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}