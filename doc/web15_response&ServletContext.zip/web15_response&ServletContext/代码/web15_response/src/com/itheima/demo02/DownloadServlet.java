package com.itheima.demo02;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;

@WebServlet(urlPatterns="/download", name="DownloadServlet")
public class DownloadServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String filename = request.getParameter("filename");

        /*********判断一下当前用户对filename文件是否有下载权限；当前用户是否有足够的金额；防盗链********/

        ServletContext context = this.getServletContext();

        /**
         * 增加两步：
         *   1. 告诉客户端，弹出下载框 下载文件，而不是显示到页面上
         *      通过一个响应头实现：Content-Disposition
         *      值的格式是：attachment;filename=弹出下载框里的文件名称
         *
         *   2. 告诉客户端，传递过去的文件类型(可选)
         *      文件类型，不是文件的后缀名，而是MIME类型
         *      String mimeType = context.getMimeType(filename)
         *      response.setContentType("image/jpeg")
         */
        //response.setHeader("Content-Disposition", "attachment;filename=" + filename);
        response.setHeader("Content-Disposition", "attachment;filename=" + DownloadUtils.encodeFilename(request, filename));
        response.setContentType(context.getMimeType(filename));

        //1. 创建输入流，读取filename指定的文件
        InputStream is = context.getResourceAsStream("/WEB-INF/files/" + filename);
        //2. 获取输出流
        ServletOutputStream os = response.getOutputStream();
        //3. 把数据写入到输出流里
        byte[] buffer = new byte[1024];
        int len = -1;
        while((len = is.read(buffer))!=-1){
            os.write(buffer, 0, len);
        }
        //4. 关闭流
        os.close();
        is.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}