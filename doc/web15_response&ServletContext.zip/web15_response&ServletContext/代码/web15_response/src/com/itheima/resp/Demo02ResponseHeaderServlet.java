package com.itheima.resp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns="/header", name="Demo02ResponseHeaderServlet")
public class Demo02ResponseHeaderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置响应头的数据
        response.setHeader("username", "lisi");

        /**
         * 有用的响应头设置：
         *  refresh：延时跳转功能。值格式：延迟秒数;url=跳转路径
         */
        //response.setHeader("refresh", "3;url=http://www.itcast.cn");

        /**
         * 重定向功能。
         * 1. 设置响应状态码为：302
         * 2. 设置一个响应头location，头值是跳转的路径
         */
        /*response.setStatus(302);
        response.setHeader("location", "http://www.itcast.cn");*/
        //response.sendRedirect("http://www.itheima.com");
        response.sendRedirect("/web15_response/index.html");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}