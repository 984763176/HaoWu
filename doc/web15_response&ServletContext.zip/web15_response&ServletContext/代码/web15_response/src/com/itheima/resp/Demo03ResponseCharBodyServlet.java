package com.itheima.resp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns="/charbody", name="Demo03ResponseCharBodyServlet")
public class Demo03ResponseCharBodyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //向页面发送字符串响应体

        /**
         * 向页面发送中文响应体乱码。乱码的根本原因：编码解码方式不一致导致的
         * 原因：
         *      response默认使用iso-8859-1编码，不支持中文
         * 解决方式一（不推荐）：
         *      设置response使用utf-8编码。response.setCharacterEncoding("utf-8")
         *      !!!还需要手动指定浏览器的解码!!!，也使用utf-8字符集，才会正常显示中文
         *
         * 解决方式二（推荐）：
         *      1. 可以设置response使用utf-8字符集编码
         *      2. 可以指定浏览器使用utf-8字符集解码
         *
         *      response.setContentType("text/html;charset=utf-8");
         */
        //response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter writer = response.getWriter();
        writer.print("传智播客");


        //在这操作数据库，从数据库里获取一些数据
        /*writer.print("<html>");
        writer.print("<body>");
        writer.print("<a href='http://www.itcast.cn'>传智播客</a>");
        writer.print("</body>");
        writer.print("</html>");*/
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
