package com.itheima.service;

import com.itheima.dao.UserDao;
import com.itheima.domain.User;

import java.util.List;

public class UserService {
    public List<User> queryAll() {
        //处理业务逻辑：略
        //调用dao，查询所有用户
        UserDao dao = new UserDao();
        List<User> userList = dao.queryAll();
        return userList;
    }
}
