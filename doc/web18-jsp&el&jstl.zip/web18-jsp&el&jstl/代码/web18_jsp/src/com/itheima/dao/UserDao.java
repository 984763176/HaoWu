package com.itheima.dao;

import com.itheima.domain.User;
import com.itheima.util.JdbcUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class UserDao {
    public List<User> queryAll() {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(JdbcUtils.getDataSource());
        List<User> userList = jdbcTemplate.query("select * from tab_user", new BeanPropertyRowMapper<>(User.class));
        return userList;
    }
}
