﻿drop database if exists javaweb;
create database javaweb;
use javaweb;
drop table if exists tab_user;
create table if not exists tab_user(
   id   int(11) primary key auto_increment,
   name varchar(50) not null,
   sex  varchar(50) not null,
   age  int(11) not null,
   address varchar(50) not null,
   qq varchar(50) not null,
   email varchar(50) not null
);

insert into tab_user values(null,'张三','男',21,'广东','766335435','zs@qq.com');
insert into tab_user values(null,'李四','男',22,'广东','243424242','ls@qq.com');
insert into tab_user values(null,'王五','女',23,'广东','474574574','ww@qq.com');
insert into tab_user values(null,'赵六','女',28,'广东','77777777', 'zl@qq.com');
insert into tab_user values(null,'钱七','女',25,'湖南','412132145','qq@qq.com');